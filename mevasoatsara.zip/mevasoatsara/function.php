<?php

function echec()
{
    echo "Information non enregistrer";
}
function success()
{
    echo "success";
}
function getLastId($name_table)
{
    global $connection;
    $sql = "SHOW TABLE STATUS LIKE '$name_table'";
    $rst = $connection->query($sql);
    $maxID = '';
    if ($rst->num_rows > 0) {
        $row = $rst->fetch_assoc();
        $maxID = $row['Auto_increment'];
    }
    return $maxID;
}
function upload_file($temp_location, $location)
{
    global $connection;
    if (move_uploaded_file($temp_location, $location)) {
        if ($connection->affected_rows>0) {
            success();
        } else {
            success();
        }
    } else {
        echec();
    }
}

function update_unit($array, $nombreLigne, $id_prod)
{
    global $connection;

    foreach ($array as $u) {
        if (count($array)==$nombreLigne) {
            $unitrequette = "UPDATE `unite_produit`  SET `id_unit` = '$u->unite',`quantite_unit`= '$u->number' where id_unite_produit = '$u->idUniteProduit'";
            $connection ->query($insertUnit);
        }
    }
}

function nav_item_simple(string $icone, string $lien, string $titre)
{
    $classe = 'nav-item';
    if ($_SERVER['SCRIPT_NAME'] == "/mevasoatsara/".$lien) {
        $classe = $classe .' active';
    }
    return '<li class="'.$classe.'">'.
                '<a class="nav-link" href="/mevasoatsara/'.$lien.'">'.
                    '<i class="'.$icone.'"></i>'.
                    '<span>'.$titre.'</span></a>'.
            '</li>';
}
function nav_sub_section(string $icone, string $lien1, string $titre1, string $lien2, string $titre2, string $titre)
{
    $classe ='';
    $content = '<li class="nav-item ">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#achat_action"
        aria-expanded="true" aria-controls="achat_action">
        <i class="far fa-money-bill-alt"></i>
        <span>Achat</span>
    </a> ';
    if($_SERVER['SCRIPT_NAME'] == '/mevasoatsara'.$lien1) {

        $content.='<div id="achat_action" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
        <a class="collapse-item active" href="'.$lien1.'">'.$titre1.'</a>
        <a class="collapse-item" href="'.$lien2.'">'.$titre2.'</a>
    </div>
    </div>
    </li>';
    }
}
