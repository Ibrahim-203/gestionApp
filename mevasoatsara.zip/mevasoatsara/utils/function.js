export var verifObligatory = (jc, action) => {
  /******************Verification des changes vides**********************/
  //Déclancheur
  jc.$content.find("form input").on(action, () => {
    var il_y_a_un_champ_vide = false;
    //Faire le tours de tout les classe .obligatoire
    //Debut boucle pour parcourir tous les champ avec la classe obligatoire
    jc.$content.find(".obligatoire").each((key, value) => {
      //Condition si il ya encore un champ vide
      if ($(value).val().trim() == "" || $(value).val().trim() == null) {
        //mettre le variable il_y_a_un_champ_vide à true
        il_y_a_un_champ_vide = true;
      }
    });
    //teste
    if (il_y_a_un_champ_vide === false) {
      jc.buttons.valider.enable();
    }
    else {
      jc.buttons.valider.disable();
    }
  });

};

export let mois = ['Janvier', 'Fevrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
export let semaine = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi']

