<?php include './include/header.php'?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary title_near_btn">Liste de ventes</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table_vente" id="table_vente" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th scope="col" width="2%">Numero</th>
                        <th scope="col">Client</th>
                        <th scope="col">Adresse client</th>
                        <th scope="col">Tel client</th>
                        <th width="15%">Etat</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Numero</th>
                        <th>Client</th>
                        <th>Adresse client</th>
                        <th>Tel client</th>
                        <th>Etat</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>

                </tbody>

            </table>
        </div>
    </div>
</div>
<?php include './include/footer.php'?>
<script type="module" src="./model/js/list_vente.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>