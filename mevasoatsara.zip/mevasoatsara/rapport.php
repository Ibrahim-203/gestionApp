<?php include './include/header.php'?>
<div class="card shadow mb-4">
    <div class="card-body">
        <h3>Efféctuer une rapport</h3>
        <div class="row">
            <div class="col-md-2">
                <select class="form-control select_by" id="select_by">
                    <option value="" selected disabled>Faite votre choix</option>
                    <option value="0">Mois</option>
                    <option value="1">Année</option>
                </select>
            </div>
            <div class="col-md-2">
                <select class="form-control select_list" id="select_list">
                </select>
            </div>
            <div class="col-md-6">
                <a name="print_rapport" id="print_rapport" class="btn btn-primary print_rapport" target="_blank"
                    href="#" role="button">Générer une rapport</a>
            </div>
        </div>
    </div>
</div>

<?php include './include/footer.php'?>
<script type="module" src="./model/js/rapport.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>