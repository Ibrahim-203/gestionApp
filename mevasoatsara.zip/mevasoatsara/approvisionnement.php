<?php include './include/header.php'?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Approvisionnement</h1>
    <p class="mb-4">Sur cette page, on approvisionne les produits.</p>
    <!-- Table for the product -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table_produit" id="table_produit" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="10%">Number</th>
                                <th>libelle produit</th>
                                <th>Quantité en stock</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Number</th>
                                <th>libelle produit</th>
                                <th>Quantité en stock</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->
    <?php include './include/footer.php'?>
    <script src="model/js/approvisionnement.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>