<?php include './include/header.php'?>

<div class="container-fluid">

    <!-- Page Heading -->
    <!-- Table for the users -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary title_near_btn">Effectué une(des) vente(s)</h6>
        </div>
        <div class="row p-1">
            <div class="col-md-3 ">
                <label for="libelle_prod">libelle produit</label>
                <select name="libelle_prod" class="form form-control" id="libelle_prod">
                </select>
            </div>
            <div class="col-md-3 ">
                <label for="unite_vente">unité de vente</label>
                <select name="unite_vente" class="form form-control" id="unite_vente">
                </select>
            </div>
            <div class="col-md-2 ">
                <label for="quantite">quantite</label>
                <input type="text" name="quantite" class="form form-control quantite" id="quantite">
                </select>
            </div>
            <div class="col-md-2 ">
                <label for="prix_unit">prix_unitaire </label>
                <input type="text" name="prix_unit" placeholder="en Ar" class="form form-control prix_unit"
                    id="prix_unit">
            </div>
            <div class="col-md-2" style="margin-top: 2rem !important">
                <button type="button" class="btn btn-primary valid_vente" name="valid_vente"
                    id="valid_vente">Valider</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table_vente" id="table_vente" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Libelle produit</th>
                            <th>Unité de vente</th>
                            <th>Quantité</th>
                            <th>Prix unitaire</th>
                            <th>Totale</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>id</th>
                            <th>Libelle produit</th>
                            <th>Unité de vente</th>
                            <th>Quantité</th>
                            <th>Prix unitaire</th>
                            <th>Totale</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody id="vente_body">

                    </tbody>
                </table>


            </div>
            <div class="row">
                <div class="col-md-6">
                    <h6>Date de l'opération (optionnel)</h6>
                    <input type="date" id="date_vente" class="form-control date_vente">
                </div>
                <div class="col-md-6">
                    <h6>heure de l'opération (optionnel)</h6>
                    <input type="time" id="heure_vente" class="form-control heure_vente">
                </div>

            </div>
            <h4>Info client</h4>
            <div class="row mb-3">
                <div class="col-md-4 mb-1">
                    <input type="text" id="nom_client" class="form-control nom_client" placeholder="Nom client">
                </div>
                <div class="col-md-3 mb-1">
                    <input type="text" id="adresse_client" class="form-control adresse_client"
                        placeholder="Adresse client">
                </div>
                <div class="col-md-2 mb-1">
                    <input type="text" id="tel_client" class="form-control tel_client" placeholder="Tel client">
                </div>
                <div class="col-md-2">
                    <button type="button" id="btn_valid_vente" class="btn btn-success btn_valid_vente "
                        disabled>Enregistrer</button>
                </div>

            </div>
        </div>
    </div>

</div>

<?php include './include/footer.php'?>
<script type="module" src="./model/js/espaceVente.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>