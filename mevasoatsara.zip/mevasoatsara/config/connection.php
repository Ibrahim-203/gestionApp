<?php

$connection = new mysqli('localhost', 'root', '', 'mevasoatsara');

if (!function_exists('displayError')) {
    function displayError()
    {
        /** Error reporting */
        error_reporting(E_ALL);
        ini_set('display_errors', true);
        ini_set('display_startup_errors', true);
        date_default_timezone_set('Europe/London');
    }
}
