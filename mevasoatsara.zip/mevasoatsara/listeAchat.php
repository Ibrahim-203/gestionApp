<?php include './include/header.php'?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary title_near_btn">Liste d'achat</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table_achat" id="table_achat" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th width="10%">Numero</th>
                        <th>Acteur</th>
                        <th>Date achat</th>
                        <th>Totale achat</th>
                        <th width="15%">Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th width="10%">Numero</th>
                        <th>Acteur</th>
                        <th>Date achat</th>
                        <th>Totale achat</th>
                        <th width="15%">Action</th>
                    </tr>
                </tfoot>
                <tbody>

                </tbody>

            </table>
        </div>
    </div>
</div>
<?php include './include/footer.php'?>
<script type="module" src="./model/js/list_achat.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>