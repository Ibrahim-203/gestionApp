import { mois, semaine } from "../../utils/function.js";
let tableVente;

const urlVente = "./model/php/DAOVente.php";
const urlprint = "./output/printVente.php";
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
const loadVente = () => {
    $("#table_vente").DataTable().clear().destroy();


    tableVente = $("#table_vente").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
        'columnDefs': [
            {
                "targets": 5, // your case first column
                "className": "text-center",
            },]
    });

    $.ajax({
        url: urlVente,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_VENTE: "SELECT_VENTE" },
        success: function (response) {
            $.each(response, function (index, val) {

                let etat
                let download

                if (val.etat_vente_groupe == 0) {
                    download = `<a href="./output/printVente.php?id=${val.id_vente_groupe}" class="btn btn-success btn-circle btn-sm mb-1 disabled" id="view_vente" data-id="${val.id_vente_groupe}" data-libelle='' ><i class="fas fa-download"></i></a>`
                    etat = `<a href="#" class="btn btn-warning etat btn-sm btn-icon-split" data-id="${val.id_vente_groupe}" data-etat="attente">
                    <span class="icon text-white-50">
                        <i class="fas fa-flag"></i>
                    </span>
                    <span class="text d-none d-xl-block">En attente</span>
                </a>`
                } else {
                    download = `<a target="_blank" href="./output/printVente.php?id=${val.id_vente_groupe}" class="btn btn-success btn-circle btn-sm mb-1" id="view_vente" data-id="${val.id_vente_groupe}" data-libelle='' ><i class="fas fa-download"></i></a>`
                    etat = `<a href="#" class="btn btn-success etat btn-sm btn-icon-split" data-id="${val.id_vente_groupe}" data-etat="livre">
                    <span class="icon text-white-50">
                        <i class="fas fa-check"></i>
                    </span>
                    <span class="text d-none d-xl-block">Livré</span>
                </a>`
                }
                let action = `${download}
                <a href="#" class="btn btn-info btn-circle btn-sm view_vente"  id="view_vente" data-id="${val.id_vente_groupe}" data-libelle=''><i class="fas fa-eye"></i></a>
                <a href="#" class="btn btn-danger btn-circle delete_vente btn-sm" id="delete_vente" data-id="${val.id_vente_groupe}" data-libelle=''><i class="fas fa-trash"></i></a>`;


                tableVente.row.add([index + 1, val.proprietaire, val.adresse_proprietaire, val.tel_proprietaire, etat, action]);
            });

            tableVente.draw();
        },
    });
};

$(function () {
    loadVente()
    $(document).on('click', '.etat', function () {
        let id = $(this).data('id')
        let etat = $(this).data('etat')
        let value
        if (etat == "attente") {
            value = 1
        } else {
            value = 0
        }
        $.confirm({
            content: function () {
                var self = this;
                return $.ajax({
                    url: urlVente,
                    method: "POST",
                    data: { UPDATE_ETAT: "UPDATE_ETAT", id: id, value: value },
                })
                    .done(function (response) {
                        if (response.indexOf("success") > -1) {
                            self.close()
                            showSuccedWal("Etat mise à jour");
                            loadVente()
                        } else {
                            self.close()
                            showErrorWal(response);
                            loadVente()
                        }
                    })
                    .fail(function () {
                        self.setContent("Something went wrong.");
                    });
            },
        });
    })

    $(document).on('click', '.view_vente', function () {
        let id = $(this).data('id')
        let content = ""
        $.ajax({
            url: urlVente,
            dataType: "JSON",
            method: "POST",
            data: { SELECT_VENTE: "SELECT_VENTE", id: id },
            success: function (response) {
                let value = response[0]
                //Créer un nouvelle objet date result : Date Tue Apr 04 2023 11:33:38 GMT+0300 (heure normale d’Afrique de l’Est)
                let date = new Date(value.date_vente);
                let etat;
                if (value.etat_vente_groupe == 1) {
                    etat = 'livré';
                } else {
                    etat = 'en attente';
                }

                //Pour la date 
                let jours_achat = date.getDay()
                let date_achat = date.getDate()
                let mois_achat = date.getMonth()
                let annee_achat = date.getFullYear()

                //Pour l'heure
                let hour = date.getHours()
                let minutes = date.getMinutes()
                let seconds = date.getSeconds()

                // Sortie 
                date = semaine[jours_achat] + ' le ' + ' ' + date_achat + ' ' + mois[mois_achat] + ' ' + annee_achat + ' à ' + hour + ':' + minutes + ':' + seconds;

                content += `
                <hr>
                <div style="float:left">
                <p>Libelle vente = Vente ${value.id_vente_groupe}</p>
                <p>Effectuée : ${date}</p>
                <p>Status : ${etat} </p>
                </div>
                <div style="float:right;">
                <p>Propriétaire : ${value.proprietaire}</p>
                <p>Tèl propriétaire : ${value.tel_proprietaire}</p>
                <p>Tèl propriétaire : ${value.adresse_proprietaire}</p>
                </div>
                
                <div style="clear:both">
                
                </div>
                <hr>
                <h5><b>Contenue vendu&nbsp; :</b></h5>
                <table border="" class="table-hover" style="width: 100%;">
                    <tbody>
                <tr class="text-secondary text-center">
                            <th style="width: 24.4691%;">Libelle produit</th>
                            <th style="width: 24.4691%;">Unite vente</th>
                        <th style="width: 25.0000%;">Quantit&eacute;</th>
                            <th style="width: 24.4691%;">Totale prix</th>
                         </tr>`;
                response.forEach(element => {
                    content += `<tr>
                                     <td style="width: 24.4691%;">${element.libelle_prod}</td>
                                     <td style="width: 24.4691%;">${element.libelle_unit}</td>
                                         <td style="width: 25.0000%;">${element.quantite}</td>
                                        <td style="width: 24.4691%;">${numberWithCommas(element.totale)}</td>
                                     </tr>`;
                });
                content += `</tbody>
                    </table>`;

                $.confirm({
                    title: 'Information sur la vente',
                    columnClass: 'xlarge',
                    content: content,
                    type: 'blue',
                    typeAnimated: true,
                    buttons: {
                        tryAgain: {
                            text: 'Ok',
                            btnClass: 'btn-blue',
                            action: function () {
                            }
                        },
                        close: function () {
                        }
                    }
                });
            },
        });


    })

    $(document).on('click', '.delete_vente', function () {
        let id = $(this).data('id');

        $.ajax({
            url: urlVente,
            method: "POST",
            data: { DELETE_VENTE: "DELETE_VENTE", id: id },
            success: function (response) {
                if (response.indexOf("success") > -1) {
                    self.close()
                    showSuccedWal("Vente supprimer");
                    loadVente()
                } else {
                    self.close()
                    showErrorWal(response);
                    loadVente()
                }
            },
        });

    })
})