const urlProd = "./model/php/DAOProd.php";
const urlUnit = "./model/php/DAOUnit.php";

let loadProduit = () => {
    $("#table_produit").DataTable().clear().destroy();

    tableProd = $("#table_produit").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
        'columnDefs': [
            {
                "targets": 3, // your case first column
                "className": "text-center",
            },]
    });

    $.ajax({
        url: urlProd,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_PRODUIT: "SELECT_PRODUIT", APPRO: "APPRO" },
        success: function (response) {
            let quantite = 0
            $.each(response, function (index, val) {

                let action = `<a href="#" class="btn btn-info btn-sm btn-circle  appro_prod" id="appro_prod" data-id='${val.id_prod}' data-libelle='${val.libelle_prod}' data-quantite='${val.quantite_stock}' data-unit='${val.libelle_unit}'><i class="fas fa-plus"></i></a>`;
                if (val.quantite_stock > 1) {
                    quantite = val.quantite_stock + ' ' + val.libelle_unit + 's'
                } else {
                    quantite = val.quantite_stock + ' ' + val.libelle_unit
                }
                tableProd.row.add([index + 1, val.libelle_prod, quantite, action]);
            });
            tableProd.draw();
        },
    });
};

$(function () {
    loadProduit()
    $(document).on("click", ".appro_prod", function () {

        const id_prod = $(this).data("id")
        const libelle_prod = $(this).data("libelle")
        const quantite = $(this).data("quantite")
        const unite = $(this).data("unit")

        $.confirm({
            columnClass: 'large',
            title: '<h6 class="text-primary">Approvisionner "' + libelle_prod + '"</h6>',
            content: '' +
                `<form action="" class="formName">
                <div class="form-group">
                <label>Stock actuel</label>
                <input type="text" value="${quantite} ${unite}" class="name form-control" readOnly />
                </div>
                <div class="form-group">
                <label>Quatité à ajouter</label>
                <input type="text" placeholder="${unite}" id="approvisionnement" class="approvisionnement form-control" required />
                </div>
                </form>`,
            buttons: {
                formSubmit: {
                    text: 'Approvisionner',
                    btnClass: 'btn-blue',
                    action: function () {
                        const quantiteAdd = $('.approvisionnement').val()
                        if (quantiteAdd && parseInt(quantiteAdd)) {
                            $.confirm({
                                content: function () {
                                    var self = this;
                                    return $.ajax({
                                        url: urlProd,
                                        method: 'POST',
                                        data: { APPROVISIONNEMENT: "APPROVISIONNEMENT", quantiteAdd, id_prod, quantite }
                                    }).done(function (response) {
                                        if (response.indexOf("success") > -1) {
                                            self.close();
                                            showSuccedWal("Produit approvisionner avec succès");
                                            loadProduit()
                                        } else {
                                            self.close();
                                            showErrorWal(response);
                                            loadProduit()
                                        }
                                    }).fail(function () {
                                        self.setContent('Something went wrong.');
                                    });
                                }
                            });
                        } else {
                            showErrorWal("Impossible d'ajouter la valeur '" + quantiteAdd + "' au produit");
                        }

                    }
                },
                cancel: function () {
                    //close
                },
            },
            onContentReady: function () {
                // bind to events
                var jc = this;
                this.$content.find('form').on('submit', function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger('click'); // reference the button and click it
                });
            }
        });
    })
})