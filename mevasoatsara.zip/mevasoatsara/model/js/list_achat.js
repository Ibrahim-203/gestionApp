import { mois, semaine } from "../../utils/function.js";
let tableAchat;
const urlAchat = "./model/php/DAOAchat.php";
const urlprint = "./output/printVente.php";

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

const loadAchat = () => {
    $("#table_achat").DataTable().clear().destroy();

    tableAchat = $("#table_achat").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
    });
    let id_user = $('body').data('id')
    $.ajax({
        url: urlAchat,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_ACHAT: "SELECT_ACHAT" },
        success: function (response) {
            $.each(response, function (index, val) {
                let prenom = val.prenom_user;
                if (val.acteur == id_user) {
                    prenom = "Moi"
                }
                let action = `<a href="#" class="btn btn-info btn-circle btn-sm view_achat" id="view_achat" data-id="${val.id_achat_groupe}" data-libelle=''><i class="fas fa-eye"></i></a>
                <a href="#" class="btn btn-warning btn-circle btn-sm edit_achat" id="edit_achat" data-id='${val.id_achat_groupe}' data-libelle=''><i class="fas fa-edit"></i></a>
                <a href="#" class="btn btn-danger btn-circle delete_achat btn-sm" id="delete_achat" data-id='${val.id_achat_groupe}' data-libelle=''><i class="fas fa-trash"></i></a>`;

                tableAchat.row.add([index + 1, prenom, val.date_achat, numberWithCommas(val.totale_achat) + " Ar", action]);
            });
            tableAchat.draw();
        },
    });
};

$(function () {
    loadAchat()

    $(document).on('click', '.view_achat', function () {
        let id = $(this).data('id')
        let content = ""
        $.ajax({
            url: urlAchat,
            dataType: "JSON",
            method: "POST",
            data: { SELECT_ACHAT: "SELECT_ACHAT", id: id },
            success: function (response) {
                let value = response[0]
                // //Créer un nouvelle objet date result : Date Tue Apr 04 2023 11:33:38 GMT+0300 (heure normale d’Afrique de l’Est)
                let date = new Date(value.date_achat);

                //Pour la date 
                let jours_achat = date.getDay()
                let date_achat = date.getDate()
                let mois_achat = date.getMonth()
                let annee_achat = date.getFullYear()

                //Pour l'heure
                let hour = date.getHours()
                let minutes = date.getMinutes()
                let seconds = date.getSeconds()

                // Sortie 
                date = semaine[jours_achat] + ' le ' + ' ' + date_achat + ' ' + mois[mois_achat] + ' ' + annee_achat + ' à ' + hour + ':' + minutes + ':' + seconds;

                content += `<p>Effectuée : ${date}</p>
                <p>Effectuée par : ${value.prenom_user}</p>
                <p>Totale crédit : ${numberWithCommas(value.totale_achat)} Ar</p>
               <h5><b>Produit acheté&nbsp; :</b></h5>
                <table border="" class="table-hover" style="width: 100%;">
                    <tbody>
                <tr class="text-secondary text-center">
                            <th style="width: 24.4691%;">Libelle produit</th>
                            <th style="width: 24.4691%;">Unite achat</th>
                        <th style="width: 25.0000%;">Quantit&eacute;</th>
                            <th style="width: 24.4691%;">Totale prix</th>
                         </tr>`;
                response.forEach(element => {
                    content += `<tr>
                                     <td style="width: 24.4691%;">${element.libelle_achat}</td>
                                     <td style="width: 24.4691%;">${element.unite_achat}</td>
                                         <td style="width: 25.0000%;">${element.quantite_achat}</td>
                                        <td style="width: 24.4691%;">${numberWithCommas(element.total_achat)} Ar</td>
                                     </tr>`;
                });
                content += `</tbody>
                    </table>`;

                $.confirm({
                    title: 'Information sur l\'achat',
                    columnClass: 'large',
                    content: content,
                    type: 'blue',
                    typeAnimated: true,
                    buttons: {
                        tryAgain: {
                            text: 'Ok',
                            btnClass: 'btn-blue',
                            action: function () {
                            }
                        },
                        fermer: function () {
                        }
                    }
                });
            },
        });


    })
})