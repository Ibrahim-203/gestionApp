const urlUnit = "./model/php/DAOUnit.php";
const urlProd = "./model/php/DAOProd.php";
const urlVente = "./model/php/DAOVente.php";
let contentTable = []
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
const fillListVente = (field, status = 0) => {
    contentTable.forEach(function (value, index) {

        let action = `<a href="#" class="btn btn-warning btn-circle edit_vente" id="edit_vente" data-libelle='${value.libelle_produit}' data-id='${value.id_produit}'><i class="fas fa-edit"></i></a>
            <a href="#" class="btn btn-danger btn-circle delete_vente" id="delete_vente" ' data-libelle='${value.libelle_produit}'><i class="fas fa-trash"></i></a>`;

        field += `<tr>
            <td>${index + 1}</td>
            <td>${value.libelle_produit}</td>
            <td>${value.unite_vente}</td>
            <td>${value.quantite}</td>
            <td>${numberWithCommas(value.prix_unit)} Ar</td>
            <td>${numberWithCommas(value.quantite * value.prix_unit)} Ar</td>
            <td>${action}</td>
        </tr>`
    })
    if (status == 0) {
        $("#prix_unit").val("")
        $("#quantite").val("")
        fillSelectProduit()
        $("#unite_vente").html("")
    }
    $('#vente_body').html(field)

}
const fillSelectUnit = (id_prod) => {
    $.ajax({
        url: urlProd,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_PRODUIT: "SELECT_PRODUIT", id_prod: id_prod },
        success: (response) => {
            let toHtml = `<option value="" selected disabled>Selectionner une unité</option>`
            $.each(response, function (index, val) {
                toHtml += `<option value="${val.id_unit}" data-quantite ="${val.quantite_unit}">${val.libelle_unit}</option>`
            })
            $("#unite_vente").html(toHtml)
        }
    })
}

const fillSelectProduit = () => {
    $.ajax({
        url: urlProd,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_PRODUIT: "SELECT_PRODUIT" },
        success: (response) => {
            let toHtml = `<option value="" selected disabled>Selectionner une produit</option>`
            $.each(response, function (index, val) {
                toHtml += `<option value="${val.id_prod}" data-quantite="${val.quantite_stock}" data-stock="${val.stock}">${val.libelle_prod}</option>`
            })
            $("#libelle_prod").html(toHtml)
        }
    })
}
let tableToHtml = ""
$(function () {
    fillSelectProduit()
    $(document).on("change", "#libelle_prod", function () {
        let id_prod = $('#libelle_prod option:selected').val()
        fillSelectUnit(id_prod)
    })
    $(document).on("click", "#valid_vente", function () {
        //Information to store
        const id_produit = $("#libelle_prod option:selected").val()
        const libelle_produit = $("#libelle_prod option:selected").text()
        const id_unite_vente = $("#unite_vente option:selected").val()
        const unite_vente = $("#unite_vente option:selected").text()
        const quantite = $("#quantite").val()
        const prix_unit = $("#prix_unit").val()
        // variable used to check disponibility of product 
        const quantite_stock = $("#libelle_prod option:selected").data("quantite")
        const stock = $("#libelle_prod option:selected").data("stock")
        const valueUnit = $("#unite_vente option:selected").data("quantite")

        if (libelle_produit && unite_vente && quantite && prix_unit) {
            if (stock == 1) {
                if ((quantite_stock - (quantite * valueUnit)) > 0) {
                    console.log(stock);
                    $("#btn_valid_vente").removeAttr("disabled")
                    contentTable.push({
                        id_produit,
                        libelle_produit,
                        id_unite_vente,
                        unite_vente,
                        quantite,
                        prix_unit
                    })
                } else {
                    showWarningWal("Stock insuffisant")
                }
            } else {
                console.log("cas 2");
                console.log(stock);
                $("#btn_valid_vente").removeAttr("disabled")
                contentTable.push({
                    id_produit,
                    libelle_produit,
                    id_unite_vente,
                    unite_vente,
                    quantite,
                    prix_unit
                })
            }

            console.log(contentTable);
        } else {
            console.log(libelle_produit);
            console.log(unite_vente);
            console.log(quantite);
            console.log(prix_unit);
        }

        fillListVente(tableToHtml)

    })

    $(document).on("click", ".delete_vente", function () {

        let value = $(this).data("libelle");
        var index = contentTable.findIndex(function (s) {
            return s.libelle_produit === value;
        });
        contentTable.splice(index, 1);
        let text = ""
        fillListVente(text)
        if (contentTable.length == 0) {
            $("#btn_valid_vente").attr("disabled", "disabled")
        }
    });
    $(document).on("click", ".edit_vente", function () {
        if ($("#quantite").val()) {
            showWarningWal("Veillez tous d'abors valider l'autre vente")
        } else {
            let libelle_produit = $(this).data("libelle")
            var index = contentTable.findIndex(function (s) {
                return s.libelle_produit === libelle_produit;
            });
            $("#libelle_prod [value=" + contentTable[index].id_produit + "]").attr("selected", "selected")

            fillSelectUnit(contentTable[index].id_produit)
            setTimeout(() => {

            }, 400);


            $("#quantite").val(contentTable[index].quantite)
            $("#prix_unit").val(contentTable[index].prix_unit)
            setTimeout(() => {
                $("#unite_vente [value=" + contentTable[index].id_unite_vente + "]").attr("selected", "selected")
                contentTable.splice(index, 1);
                let text = ""
                fillListVente(text, 1)
            }, 100);
        }







    })

    // Stocké le vente 
    $(document).on('click', ".btn_valid_vente", function () {
        let id_user = $('body').data('id')
        let nom_client = $(".nom_client").val();
        let adresse_client = $(".adresse_client").val();
        let tel_client = $(".tel_client").val();
        let date_vente = $(".date_vente").val();
        let heure_vente = $(".heure_vente").val();

        if (nom_client && adresse_client && tel_client) {
            let list_vente = JSON.stringify(contentTable)
            $.confirm({
                content: function () {
                    var self = this;
                    return $.ajax({
                        url: urlVente,
                        method: 'post',
                        data: { INSERT_VENTE: "INSERT_VENTE", list_vente: list_vente, nom_client: nom_client, adresse_client: adresse_client, tel_client: tel_client, date_vente, id_user, heure_vente }
                    }).done(function (response) {
                        self.close()
                        showSuccedWal("Vente effectuée");
                        contentTable = []
                        fillListVente(tableToHtml)
                    }).fail(function () {
                        self.close()
                        showErrorWal("Erreur d'enregistrement");
                        self.setContent('Something went wrong.');
                    });
                }
            });

        } else {
            showWarningWal("Veillez remplir les informations du client")

        }

    })
})