let tableAchat;
const urlAchat = "./model/php/DAOAchat.php";
const urlprint = "./output/printVente.php";

let contentTable = []
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
let content = ""
const fillListAchat = (table, field, status = 0) => {
    table.forEach(function (value, index) {

        let action = `<a href="#" class="btn btn-warning btn-circle btn-sm edit_achat" id="edit_achat" data-libelle='${value.libelle_achat}' ><i class="fas fa-edit"></i></a>
            <a href="#" class="btn btn-danger btn-circle btn-sm delete_achat" id="delete_achat" ' data-libelle='${value.libelle_produit}'><i class="fas fa-trash"></i></a>`;

        field += `<tr>
            <td>${index + 1}</td>
            <td>${value.libelle_achat}</td>
            <td>${value.motif}</td>
            <td>${value.quantite} ${value.unite}</td>
            <td>${numberWithCommas(value.prix_unit)} Ar</td>
            <td>${numberWithCommas(value.quantite * value.prix_unit)} Ar</td>
            <td>${action}</td>
        </tr>`
    })
    if (status == 0) {
        $("#libelle_achat").val("")
        $("#motif").val("")
        $("#prix_unit").val("")
        $("#quantite").val("")
        $("#unite").val("")
    }
    $('#achat_body').html(field)

}

const loadAchat = () => {
    $("#table_achat").DataTable().clear().destroy();

    tableAchat = $("#table_achat").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
    });

    $.ajax({
        url: urlAchat,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_ACHAT: "SELECT_ACHAT" },
        success: function (response) {
            $.each(response, function (index, val) {
                let action = `<a href="./output/printVente.php?id=${val.id_achat_groupe}" class="btn btn-info btn-circle btn-sm " id="view_vente" data-id="${val.id_achat_groupe}" data-libelle=''><i class="fas fa-eye"></i></a>
                <a href="#" class="btn btn-warning btn-circle btn-sm edit_unit" id="edit_unit" data-id='' data-libelle=''><i class="fas fa-edit"></i></a>
                <a href="#" class="btn btn-danger btn-circle delete_unit btn-sm" id="delete_unit" data-id='' data-libelle=''><i class="fas fa-trash"></i></a>`;

                tableAchat.row.add([index + 1, 'Achat ' + (index + 1), val.date_achat, val.totale_achat, action]);
            });
            tableAchat.draw();
        },
    });
};

$(function () {

    $(document).on("click", "#valid_achat", function () {
        const libelle_achat = $("#libelle_achat").val()
        const motif = $("#motif").val()
        const unite = $("#unite").val()
        const quantite = $("#quantite").val()
        const prix_unit = $("#prix_unit").val()


        if (libelle_achat && motif && quantite && prix_unit && unite) {
            $("#btn_valid_achat").removeAttr("disabled")
            contentTable.push({
                libelle_achat,
                motif,
                quantite,
                unite,
                prix_unit
            })
            console.log(contentTable);
        } else {
            console.log(libelle_achat);
            console.log(motif);
            console.log(quantite);
            console.log(prix_unit);
        }
        content = ""
        fillListAchat(contentTable, content)

    })

    $(document).on("click", ".edit_achat", function () {
        if ($("#quantite").val()) {
            showWarningWal("Veillez tous d'abors valider l'autre vente")
        } else {
            let libelle_achat = $(this).data("libelle")
            var index = contentTable.findIndex(function (s) {
                return s.libelle_achat === libelle_achat;
            });
            $("#libelle_achat").val(contentTable[index].libelle_achat)

            $("#quantite").val(contentTable[index].quantite)
            $("#prix_unit").val(contentTable[index].prix_unit)
            $('#motif').val(contentTable[index].motif)
            $("#unite").val(contentTable[index].unite)
            contentTable.splice(index, 1);
            let text = ""
            fillListAchat(contentTable, text, 1)
        }
    })

    $(document).on("click", ".delete_achat", function () {

        let value = $(this).data("libelle");
        var index = contentTable.findIndex(function (s) {
            return s.libelle_achat === value;
        });
        contentTable.splice(index, 1);
        let text = ""
        fillListAchat(contentTable, text)
        if (contentTable.length == 0) {
            $("#btn_valid_achat").attr("disabled", "disabled")
        }
    });

    // Stocké le achat 
    $(document).on('click', ".btn_valid_achat", function () {
        let id_user = $('body').data('id')
        let date_achat = $(".date_achat").val();
        let heure_achat = $(".heure_achat").val();
        $('.date_achat').val('')
        $('.heure_achat').val('')
        if (contentTable != "") {
            let list_achat = JSON.stringify(contentTable)
            $.confirm({
                content: function () {
                    var self = this;
                    return $.ajax({
                        url: urlAchat,
                        method: 'post',
                        data: { INSERT_ACHAT: "INSERT_ACHAT", list_achat: list_achat, date_achat, heure_achat, id_user }
                    }).done(function (response) {
                        self.close()
                        showSuccedWal("Achat enregistrée");
                        contentTable = []
                        content = ""
                        fillListAchat(contentTable, content)
                    }).fail(function () {
                        self.close()
                        showErrorWal("Erreur d'enregistrement");
                        self.setContent('Something went wrong.');
                    });
                }
            });
        } else {
            showWarningWal("Vous n'avez aucune list d'achat")
        }


    })

})