import { mois, semaine } from "../../utils/function.js";
const urlRapport = "./model/php/DAORapport.php";
const fillSelectUnit = () => {
    $.ajax({
        url: urlRapport,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_REPORT: "SELECT_REPORT" },
        success: (response) => {
            let toHtml = `<option value="" selected disabled>Selectionner une mois</option>`
            $.each(response, function (index, val) {
                toHtml += `<option value="${val.id}">${val.libelle_unit}</option>`
            })
            $("#unit").html(toHtml)
        }
    })
}
const fillSelectList = (choice) => {
    let toHtml = ""
    if (choice == 0) {
        toHtml = `<option value="" selected disabled>Selectionner une mois</option>`
        $.each(mois, function (index, val) {

        })
        for (let index = 0; index < mois.length; index++) {
            toHtml += `<option value="${index + 1}">${mois[index]}</option>`
        }
    } else {
        toHtml = `<option value="" selected disabled>Selectionner l'année</option>`
        let date = new Date
        let year = date.getFullYear()
        if (year == "2023") {
            toHtml += `<option value="${2023}">${2023}</option>`
        } else {
            for (let index = 2023; index < year; index++) {
                toHtml += `<option value="${index}">${index}</option>`

            }
        }
    }

    $("#select_list").html(toHtml)
}
$(function () {

    $(document).on("change", "#select_by", function () {
        let choice = $("#select_by option:selected").val()
        fillSelectList(choice)
    })
    $(document).on("change", "#select_list", function () {
        let selectedBy = $("#select_by option:selected").val()
        let selectedList = $("#select_list option:selected").val()
        if (selectedBy == 0) {
            $("#print_rapport").attr('href', `./output/printReport.php?mois=${selectedList}`)
        } else {
            $("#print_rapport").attr('href', `./output/printReport.php?annee=${selectedList}`)
        }
    })
})