export var loadStatisticOfvente = () => {
    let data = []
    $.ajax({
        url: urlIndex,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_STATISTIC: "SELECT_STATISTIC", chart: "chart" },
        success: function (response) {
            const value = response[0]
            let dataRepaire = [value.janvier, value.fevrier, value.mars, value.avril, value.mai, value.juin, value.juillet, value.aout, value.septembre, value.octobre, value.novembre, value.decembre]

            dataRepaire.forEach(element => {
                if (element == null) {
                    element = 0
                }
                data.push(element)
            });
        },
        async: false
    });
    return data;
}
const urlIndex = "./model/php/DAOIndex.php";
let loadStatistic = () => {

    $.ajax({
        url: urlIndex,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_STATISTIC: "SELECT_STATISTIC" },
        success: function (response) {

            let statistic = ""
            let achat = "Nombre d'achat"
            let produit = "Nombre de produit"
            let vente = "Nombre de vente"
            let utilisateur = "Nombre d'utilisateur"
            if (response[0].achat > 1) {
                achat = "Nombres d'achat"
            }
            if (response[0].produit > 1) {
                produit = "Nombres de produit"
            }
            if (response[0].vente > 1) {
                vente = "Nombres de vente"
            }
            if (response[0].user > 1) {
                utilisateur = "Nombres d'utilisateur"
            }

            statistic = `<!-- Achat Card Example -->
            
            <div class="col-xl-3 col-md-6 mb-4">
            <a href="./listeAchat.php">
                <div class="card link-card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    ${achat}</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">${response[0].achat}</div>
                            </div>
                            <div class="col-auto">
                                <i class="far fa-money-bill-alt fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
                </a>
            </div>
            <!--ProduitCard Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="./produit.php">
                    <div class="card link-card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        ${produit}</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">${response[0].produit}</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-carrot fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
    
            <!-- Utilisateur Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
            <a href="./user.php">
                <div class="card link-card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">${utilisateur}
                                </div>
                                <div class="row no-gutters align-items-center">
                                    <div class="col-auto">
                                        <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">${response[0].user}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-users fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
            </div>
    
            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
            <a href="./listeVente.php">
                <div class="card link-card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    ${vente}</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">${response[0].vente}</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-warehouse fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            </div>`

            $('.card_statistic').html(statistic)
        },
    });
};

$(function () {
    loadStatistic()
})