import { verifObligatory } from "../../utils/function.js";
let tableUser;
const urlUser = "./model/php/DAOUser.php";
const loadUser = () => {
    $("#table_user").DataTable().clear().destroy();

    tableUser = $("#table_user").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
    });

    $.ajax({
        url: urlUser,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_USER: "SELECT_USER" },
        success: function (response) {
            $.each(response, function (index, val) {
                let action = `<a href="#" class="btn btn-warning btn-circle btn-sm edit_user" id="edit_user"  title="Modifier l'utilisateur" data-id='${val.id_user}' data-libelle='${val.nom_user}'><i class="fas fa-edit"></i></a>
                <a href="#" class="btn btn-info btn-circle btn-sm edit_password" id="edit_password" title="Modifier le mot de passe" data-id='${val.id_user}' data-libelle='${val.nom_user}' data-image='${val.image_user}'><i class="fas fa-lock"></i></a>
                <a href="#" class="btn btn-danger btn-circle btn-sm delete_user" id="delete_user" title="Supprimer l'utilisateur" data-id='${val.id_user}' data-libelle='${val.nom_user}' data-image='${val.image_user}'><i class="fas fa-trash"></i></a>`;



                tableUser.row.add([index + 1, val.nom_user + ' ' + val.prenom_user, val.tel_user, val.adresse_user, action]);
            });
            tableUser.draw();
        },
    });
};
$(function () {

    //Run function to fill table of user
    loadUser()

    //Add event on click in button add user
    $(document).on("click", "#add_user", function () {

        console.clear();
        $.confirm({
            columnClass: "large",
            title: "Ajouter un/une utilisateur ",
            content:
                "" +
                `<div class="widget-content widget-content-area">
        <form class="simple-example" enctype="multipart/form-data" novalidate>
        <!-- columns -->
<div class="form-group">
<div class="form-row align-items-center">
	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="nom_user">Nom *</label>
	<input type="text" class="form-control form-control-sm obligatoire" name="nom_user" id="nom_user" required>
		</div>

	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="prenom_user">Prénom *</label>
	<input type="text" class="form-control form-control-sm obligatoire" name="prenom_user" id="prenom_user" required>
		</div>

</div>

</div>

<!-- columns -->
<div class="form-group">
<div class="form-row align-items-center">
	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="tel_user">Téléphone *</label>
	<input type="number" class="form-control form-control-sm integer" name="tel_user" id="tel_user">
    <b id="error" class="text-danger"></b>
		</div>

	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="adresse_user">Adresse *</label>
	<input type="text" class="form-control form-control-sm obligatoire" name="adresse_user" id="adresse_user">
		</div>

</div>

</div>

<div class="form-group">
<div class="form-row align-items-center">
	<div class="col-md-6 mb-3">
<!-- Input type text -->
<label for="password">Mot de passe</label>
<input type="password" class="form-control form-control-sm mb-2 obligatoire password" name="password" id="password" ></div>

	<div class="col-md-6 mb-3">
<!-- Input type text -->
<label for="password1">Repéter le mot de passe</label>
<input type="password" class="form-control form-control-sm mb-2 obligatoire password1" name="password1" id="password1" >
		</div>

</div>

</div>

<!-- Input type text -->
<div class="form-group">
<div class="form-row align-item-center">
<div class="col-md-6 mb-3">
	<label for="date_naiss_user">Date de naissance *</label>
	<input type="date" class="form-control form-control-sm obligatoire" name="date_naiss_user" id="date_naiss_user">
</div>
<div class="col-md-6 mb-4">
<label>Sexe</label>
<div>
    <div class="custom-control custom-radio custom-control-inline">
        <input class="custom-control-input sexe_user" type="radio" name="sexe_user" id="masculin" value="masculin" checked>
        <label class="custom-control-label" for="masculin">Masculin</label>
    </div>
    <div class="custom-control custom-radio custom-control-inline">
        <input class="custom-control-input sexe_user" type="radio" name="sexe_user" id="feminin" value="feminin">
        <label class="custom-control-label" for="feminin">Féminin</label>
    </div>
</div>
</div>
</div>
</div>
      <div class="col-md-12 mb-4">
      <div class="form-group">
	<label for="image_user">Image utilisateur</label>
	<input type="file" class="form-control form-control-sm mb-2" name="image_user" id="imgInp" placeholder="file">
  <img src="./img/default_homme.png" id="blah" accept="image/png, image/jpeg" src="#" alt="Inserer une image" />
</div>
</div>
      </div>
      </form>
      </div>`,
            buttons: {

                valider: {

                    text: "Enregistrer",
                    btnClass: "btn-blue",
                    action: function () {
                        const mot_de_pass = $(".password").val()
                        const mot_de_pass1 = $(".password1").val()
                        if (mot_de_pass == mot_de_pass1) {
                            $.confirm({
                                content: function () {
                                    var formulaire = $(".simple-example")[0];
                                    var formData = new FormData(formulaire);

                                    formData.append("ADD_EDIT", "ADD_EDIT");
                                    var self = this;
                                    return $.ajax({
                                        url: urlUser,
                                        method: "POST",
                                        data: formData,
                                        cache: false,
                                        processData: false,
                                        contentType: false,
                                    })
                                        .done(function (response) {
                                            if (response.indexOf("success") > -1) {
                                                self.close();
                                                showSuccedWal("Information modifiée avec succès");
                                                loadUser();
                                            } else {
                                                self.close();
                                                showErrorWal(response);
                                                loadUser();
                                            }
                                        })
                                        .fail(function () {
                                            self.setContent("Something went wrong.");
                                        });
                                },
                            });
                        } else {
                            showErrorWal("Mot de passe non identique")
                        }

                    },
                },
                annuler: function () {
                    //close
                },
            },
            onContentReady: function () {
                imgInp.onchange = evt => {
                    const [file] = imgInp.files
                    if (file) {
                        blah.src = URL.createObjectURL(file)
                    }
                }
                var jc = this;
                jc.buttons.valider.disable();
                verifObligatory(jc, "keyup keydown change");

                // bind to events
                this.$content.find("form").on("submit", function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger("click"); // reference the button and click it
                });

                //Déclancheur
                jc.$content.find("form input").on("keyup", function (e) {
                    jc.$content.find(".integer").each((key, value) => {

                        // if (
                        //     !["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"].includes(
                        //         e.key
                        //     )
                        // ) {
                        //     var valArr = $(value).val();
                        //     $(value).val(valArr.replace(e.key, ""));

                        //     $(this).parent().find("#error").text("Champ numérique")
                        //     // console.log(
                        //     //   "$(value).closest()",
                        //     //   $(value).parent().append("<b>Champ numérique<b/>")
                        //     // );
                        // } else {
                        //     $(this).parent().find("#error").text("")
                        // }
                        if ($.isNumeric($(this).val())) {
                            $(this).parent().find("#error").text("")
                        } else {
                            jc.buttons.valider.disable();
                            $(this).parent().find("#error").text("Champ numérique")
                        }
                    });
                });
            },
        });
    });

    //Add event on click in button edit user
    $(document).on("click", "#edit_user", function () {
        let id = $(this).data("id");
        let libelle = $(this).data("libelle");
        console.clear();
        $.confirm({
            columnClass: "large",
            title: "Modifier l'utilisateur " + libelle,
            content:
                "" +
                `<div class="widget-content widget-content-area">
        <form class="simple-example" enctype="multipart/form-data" novalidate>
        <!-- columns -->
<div class="form-group">
<div class="form-row align-items-center">
	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="nom_user">Nom *</label>
	<input type="text" class="form-control form-control-sm obligatoire" name="nom_user" id="nom_user" required>
    </div>

	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="prenom_user">Prénom *</label>
	<input type="text" class="form-control form-control-sm obligatoire" name="prenom_user" id="prenom_user" required>
		</div>

</div>

</div>

<!-- columns -->
<div class="form-group">
<div class="form-row align-items-center">
	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="tel_user">Téléphone *</label>
	<input type="number" class="form-control form-control-sm integer" name="tel_user" id="tel_user">
    <b id="error" class="text-danger"></b>
		</div>

	<div class="col-md-6 mb-3">
<!-- Input type text -->
	<label for="adresse_user">Adresse *</label>
	<input type="text" class="form-control form-control-sm obligatoire" name="adresse_user" id="adresse_user">
		</div>

</div>

</div>

<!-- Input type text -->
<div class="form-group">
<div class="form-row align-items-center">
<div class="col-md-6 mb-4">
	<label for="date_naiss_user">Date de naissance *</label>
	<input type="date" class="form-control form-control-sm obligatoire" name="date_naiss_user" id="date_naiss_user">
</div>
<div class="col-md-6 mb-4">
<label>Sexe</label>
<div>
    <div class="custom-control custom-radio custom-control-inline">
        <input class="custom-control-input" type="radio" name="sexe_user" id="masculin" value="masculin" checked>
        <label class="custom-control-label" for="masculin">Masculin</label>
    </div>
    <div class="custom-control custom-radio custom-control-inline">
        <input class="custom-control-input" type="radio" name="sexe_user" id="feminin" value="feminin">
        <label class="custom-control-label" for="feminin">Féminin</label>
    </div>
</div>
</div>
</div>
      <div class="col-md-12 mb-4">
      <div class="form-group">
	<label for="image_user">Image utilisateur</label>
	<input type="file" class="form-control form-control-sm mb-2" name="image_user" id="imgInp" placeholder="file">
  <img src="./img/default_homme.png" id="blah" accept="image/png, image/jpeg" src="#" alt="Inserer une image" />
</div>
</div>
      </div>
      </form>
      </div>`,
            buttons: {
                valider: {
                    text: "Modifier",
                    btnClass: "btn-blue",
                    action: function () {
                        $.confirm({
                            content: function () {
                                var formulaire = $(".simple-example")[0];
                                var formData = new FormData(formulaire);

                                formData.append("ADD_EDIT", "ADD_EDIT");
                                formData.append("id_user", id);
                                var self = this;
                                return $.ajax({
                                    url: urlUser,
                                    method: "POST",
                                    data: formData,
                                    cache: false,
                                    processData: false,
                                    contentType: false,
                                })
                                    .done(function (response) {
                                        if (response.indexOf("success") > -1) {
                                            self.close();
                                            showSuccedWal("Information modifiée avec succès");
                                            loadUser();
                                        } else {
                                            self.close();
                                            showErrorWal(response);
                                            loadUser();
                                        }
                                    })
                                    .fail(function () {
                                        self.setContent("Something went wrong.");
                                    });
                            },
                        });
                    },
                },
                annuler: function () {
                    //close
                },
            },
            onContentReady: function () {
                imgInp.onchange = evt => {
                    const [file] = imgInp.files
                    if (file) {
                        blah.src = URL.createObjectURL(file)
                    }
                }

                var jc = this;
                $(document).on("click", ".clear", function () {
                    jc.buttons.valider.disable();
                });
                jc.buttons.valider.disable();
                verifObligatory(jc, "keyup change");
                // verifObligatory(jc);

                // bind to events
                this.$content.find("form").on("submit", function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger("click"); // reference the button and click it
                });

                //Déclancheur
                jc.$content.find("form input").on("keyup keydown", (e) => {
                    jc.$content.find(".integer").each((key, value) => {
                        if (
                            !["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"].includes(
                                e.key
                            )
                        ) {
                            var valArr = $(value).val();
                            $(value).val(valArr.replaceAll(e.key, ""));
                            // console.log(
                            //   "$(value).closest()",
                            //   $(value).parent().append("<b>Champ numérique<b/>")
                            // );
                        }
                    });
                });
            },
            onOpenBefore: function () {
                $.confirm({
                    content: function () {
                        var self = this;
                        return $.ajax({
                            url: urlUser,
                            dataType: "JSON",
                            method: "POST",
                            data: { SELECT_USER: "SELECT_USER", id_user: id },
                        }).done(function (response) {
                            self.close();
                            // console.log(response);
                            let value = response[0];
                            $("#nom_user").val(value.nom_user);
                            $("#prenom_user").val(value.prenom_user);
                            $("#tel_user").val(value.tel_user);
                            $("#adresse_user").val(value.adresse_user);
                            $("#date_naiss_user").val(value.date_naiss_user);
                            $("#" + value.sexe_user).prop('checked', true);
                            if (!value.image_user) {
                                $("#blah").attr('src', './img/default_homme.png')
                            } else {
                                $("#blah").attr('src', './upload/' + value.image_user + '')
                            }
                        });
                    },
                });
            },
        });
    });

    //Add event on click in button delete user
    $(document).on("click", "#delete_user", function () {

        const id_user = $(this).data("id")
        const nom_user = $(this).data("libelle")
        const image_user = $(this).data("image")
        $.confirm({
            title: `Supprimer l'utilisateur "${nom_user}"`,
            content: 'Cette action est irreversible,Voulez-vous vraiment supprimer cette utilisateur?',
            type: 'red',
            typeAnimated: true,
            buttons: {
                Supprimer: {
                    text: 'Supprimer',
                    btnClass: 'btn-red',
                    action: function () {
                        $.confirm({
                            content: function () {
                                var self = this;
                                return $.ajax({
                                    url: urlUser,
                                    method: 'POST',
                                    data: { DELETE_USER: "DELETE_USER", id_user: id_user, image_user: image_user }
                                }).done(function (response) {
                                    if (response.indexOf("success") > -1) {
                                        self.close();
                                        showSuccedWal("Suppression éfféctuer");
                                        loadUser();
                                    } else {
                                        self.close();
                                        showErrorWal("Erreur de suppression");
                                        loadUser();
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    }
                },
                annuler: function () {
                }
            }
        });
    })
    $(document).on("change", ".sexe_user", function () {
        let value = $(this).val()
        if (value == "masculin") {
            $("#blah").attr('src', './img/default_homme.png')
        } else {
            $("#blah").attr('src', './img/default_femme.png')
        }
    })

    $(document).on("click", ".edit_password", function () {
        const id = $(this).data("id");
        console.log(id);
        $.confirm({
            columnClass: "large",
            title: "Changer le mot de passe",
            content:
                "" +
                `<div class="widget-content widget-content-area">
            <form class="simple-example" enctype="multipart/form-data" novalidate>
            <div class="form-row">
          <div class="col-md-12 mb-4">

          <label for="old_pass">Ancien mot de passe</label>
          <input type="text" class="form-control obligatoire" name="old_pass" id="old_pass" >
          </div>
          <div class="col-md-12 mb-4">
          <label for="fullName">Nouveau mot de passe</label>
          <input type="password" class="form-control obligatoire" name="new_pass_1" id="new_pass_1" >
          </div>
          <div class="col-md-12 mb-4">
          <label for="fullName">Nouveau mot de passe</label>
          <input type="password" class="form-control obligatoire" name="new_pass_2" id="new_pass_2" >
          </div>
          </div>
          </form>
          </div>`,
            buttons: {
                valider: {
                    text: "Modifier",
                    btnClass: "btn-blue",
                    action: function () {
                        let old_pass = $("#old_pass").val();
                        let new_pass_1 = $("#new_pass_1").val();
                        let new_pass_2 = $("#new_pass_2").val();
                        $.confirm({
                            content: function () {
                                var self = this;
                                return $.ajax({
                                    url: urlUser,
                                    method: "POST",
                                    data: { old_pass, new_pass_1, new_pass_2, id_user: id, UPDATE_PASS: "UPDATE_PASS" },
                                })
                                    .done(function (response) {
                                        if (response.indexOf("success") > -1) {
                                            self.close();
                                            showSuccedWal(response);
                                            window.location = "./";
                                        } else {
                                            self.close();
                                            showErrorWal(response);
                                        }
                                    })
                                    .fail(function () {
                                        self.setContent("Something went wrong.");
                                    });
                            },
                        });
                    },
                },
                annuler: function () {
                    //close
                },
            },
            onContentReady: function () {
                var jc = this;
                jc.buttons.valider.disable();
                verifObligatory(jc, "keyup ");
                // verifObligatory(jc);

                // bind to events
                this.$content.find("form").on("submit", function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger("click"); // reference the button and click it
                });

                //Déclancheur
                jc.$content.find("form input").on("keyup keydown", (e) => {
                    jc.$content.find(".integer").each((key, value) => {
                        if (
                            !["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"].includes(
                                e.key
                            )
                        ) {
                            var valArr = $(value).val();
                            $(value).val(valArr.replaceAll(e.key, ""));
                        }
                    });
                });
            },
        });
    })
})
