const urlUnit = "./model/php/DAOUnit.php";

let storage = [];
let toHtml = "";

let loadProduit = () => {
    $("#table_produit").DataTable().clear().destroy();

    tableProd = $("#table_produit").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
    });

    $.ajax({
        url: "./model/php/DAOCat.php",
        dataType: "JSON",
        method: "POST",
        data: { SELECT_CAT: "SELECT_CAT" },
        success: function (response) {
            $.each(response, function (index, val) {
                let action = `<ul class="table-controls">
          <li><a href="javascript:void(0);" id="add_equip" class="bs-tooltip" data-id="${val.id}" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="flaticon-plus-1  p-1 br-6 mb-1"></i></a></li>
            <li><a href="javascript:void(0);" id="edit_cat" class="bs-tooltip" data-id="${val.id}" data-libelle="${val.libelle_cat}" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="flaticon-edit  p-1 br-6 mb-1"></i></a></li>
            <li><a href="javascript:void(0);" id="delete_cat" data-id="${val.id}" data-image="${val.image_cat}" data-libelle="${val.libelle_cat}" class="bs-tooltip" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="flaticon-delete  p-1 br-6 mb-1"></i></a></li>
            </ul>`;

                tableProd.row.add([index + 1, val.libelle_cat, action]);
            });
            tableProd.draw();
        },
    });
};

const fillSelectUnit = () => {
    $.ajax({
        url: urlUnit,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_UNIT: "SELECT_UNIT" },
        success: (response) => {
            let toHtml = `<option value="" selected disabled>Selectionner une unité</option>`
            $.each(response, function (index, val) {
                toHtml += `<option value="${val.id}">${val.libelle_unit}</option>`
            })
            $("#unit").html(toHtml)
        }
    })
}

const fillArray = function (field) {
    field = "";
    storage.forEach(function (value) {
        field += `<div class="form-group">
        <div class="form-row align-items-center">
            <div class="col-md-5 mb-3">
        <!-- Input type text -->
            <input type="text" class="form-control valUnit" data-id="${value.unite}" value="${value.textUnit}" name="valUnit" id="valUnit"  readOnly>
                </div>
        
            <div class="col-md-5 mb-3">
        <!-- Input type text -->
            <input type="text" class="form-control numberUnit" value="${value.number}" name="numberUnit" id="numberUnit" placeholder="quantité">
                </div>
        
            <div class="col-md-2 mb-3">
            <a href="#" id="btn_remove_line" class="btn btn-outline-danger btn_remove_line btn-circle" data-val="${value.textUnit}"><i class="fas fa-trash"></i></a>
        
            </div>
        
        </div>
        
        </div>`;
    });
    $("#list_field").html(field);
};

$(function () {
    $(document).on("click", "#add_product", function () {
        $.confirm({
            columnClass: "large",
            title: 'Ajouter une produit',
            content: '' +
                `<div class="widget-content widget-content-area">
                <form class="simple-example" enctype="multipart/form-data" novalidate>
                <!-- columns -->
        <div class="form-group">
        <div class="form-row align-items-center">
            <div class="col-md-6 mb-3">
        <!-- Input type text -->
            <label for="libelle_prod">Libelle produit *</label>
            <input type="text" class="form-control form-control-sm obligatoire" name="libelle_prod" id="libelle_prod" required>
                </div>
        
            <div class="col-md-6 mb-3">
        <!-- Input type text -->
            <label for="prenom_user">Prix unitaire *</label>
            <input type="text" class="form-control form-control-sm obligatoire" name="prix_unit" id="prix_unit" required>
                </div>
        
        </div>
        
        </div>
        <div class="col-md-12 pl-0 mb-2">
        <label for="unite_vente">Unité(s) de vente *</label>
        </div>
        <!-- columns -->
        <div class="form-group">
        <div class="form-row align-items-center">
            <div class="col-sm-5 mb-3">
        <!-- Input type text -->
            <select class="form-control form-control-sm unit" name="unit" id="unit"> </select>
                </div>
                <div class="col-sm-5 mb-3">
        <!-- Input type text -->
        <input type="text" id="number" class="form-control form-control-sm" placeholder="quantité" value="" />
                </div>
        
            <div class="col-md-2 col-sm-2 mb-3">
        <!-- Input type text -->
            <a href="#" id="btn-valid" class="btn btn-success btn-valid btn-circle"><i class="fas fa-check"></i></a>
                </div>
        
        </div>
        
        </div>
        
        <!-- Multiple field -->
        <div id="list_field" class = "list_field">
        
</div>
        <!-- Input type text -->
        <div class="form-group">
        <div class="form-row align-item-center">
        <div class="col-md-4 mb-4">
        <label>Stockable</label>
        <div>
            <div class="custom-control custom-radio custom-control-inline">
                <input class="custom-control-input Stockable" type="radio" name="Stockable" id="oui" value="1" checked>
                <label class="custom-control-label" for="oui">Oui</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
                <input class="custom-control-input Stockable" type="radio" name="Stockable" id="non" value="0">
                <label class="custom-control-label" for="non">Non</label>
            </div>
        </div>
        </div>
        <div class="col-md-8 mb-3">
            <label for="quantite_stock">Quantité en stock *</label>
            <input type="text" style="width:70%" class="form-control form-control-sm obligatoire" name="quantite_stock" id="quantite_stock" >
        </div>
        </div>
        </div>
              <div class="col-md-12 mb-4">
              <div class="form-group">
            <label for="image_prod">Image Produit</label>
            <input type="file" class="form-control form-control-sm mb-2" name="image_prod" id="imgInp" placeholder="file">
          <img src="./img/default_homme.png" id="blah" accept="image/png, image/jpeg" src="#" alt="Inserer une image" />
        </div>
        </div>
              </div>
              </form>
              </div>`,
            buttons: {
                formSubmit: {
                    text: 'Submit',
                    btnClass: 'btn-blue',
                    action: function () {
                        var name = this.$content.find('.name').val();
                        if (!name) {
                            $.alert('provide a valid name');
                            return false;
                        }
                        $.alert('Your name is ' + name);
                    }
                },
                cancel: function () {
                    //close
                },
            },
            onContentReady: function () {
                imgInp.onchange = evt => {
                    const [file] = imgInp.files
                    if (file) {
                        blah.src = URL.createObjectURL(file)
                    }
                }
                // bind to events
                var jc = this;
                this.$content.find('form').on('submit', function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger('click'); // reference the button and click it
                });
            },
            onOpenBefore: function () {
                fillSelectUnit()
            }
        });
    })
    $(document).on("change", ".Stockable", function () {

        if ($(this).val() == 1) {
            console.log("OUiiii");
            $("#quantite_stock").removeAttr("disabled")
            $("#quantite_stock").addClass("obligatoire")
        } else {
            console.log("Nonnnnn");
            $("#quantite_stock").attr("disabled", "disabled")
            $("#quantite_stock").removeClass("obligatoire")
            $("#quantite_stock").val("")
        }
    })

    $(document).on("click", "#btn-valid", function () {
        let textSelected = $("#unit option:selected").text();
        let valSelected = $("#unit option:selected").val();
        let number = $("#number").val();
        if (number) {
            $('#number').val("")
            if (storage == "") {
                storage.push({
                    unite: valSelected,
                    textUnit: textSelected,
                    number: number,
                });
            } else {
                let existe = storage.find((s) => s.textUnit === textSelected);
                if (existe) {
                    console.log("existe");
                } else {
                    storage.push({
                        unite: valSelected,
                        textUnit: textSelected,
                        number: number,
                    });
                }
            }
        }
        // function to fill the multified
        fillArray(toHtml);
    });

    $(document).on("click", ".btn_remove_line", function () {
        let value = $(this).data("val");
        var index = storage.findIndex(function (s) {
            return s.textUnit === value;
        });
        storage.splice(index, 1);
        fillArray(toHtml);
    });
})