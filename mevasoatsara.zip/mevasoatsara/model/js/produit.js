const urlProd = "./model/php/DAOProd.php";
const urlUnit = "./model/php/DAOUnit.php";
let storage = [];
let toHtml = "";
let nombreLigne

const loadEditUnit = (id_prod) => {

    $.ajax({
        url: urlProd,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_UNIT: "SELECT_UNIT", id: id_prod },
        success: function (response) {
            let html = ""
            $.each(response, function (index, value) {

                html += `<div class="form-group">
        <div class="form-row align-items-center">
            <div class="col-md-5 mb-3">
        <!-- Input type text -->
            <input type="text" class="form-control valUnit" data-id="${value.id_unite_produit}" value="${value.libelle_unit}" name="valUnit" id="valUnit"  readOnly>
                </div>
        
            <div class="col-md-5 mb-3">
        <!-- Input type text -->
            <input type="text" class="form-control numberUnit" 
            data-modif = "modification" data-id="${value.id_unite_produit}" value="${value.quantite_unit}" name="numberUnit" id="numberUnit" placeholder="quantité" readOnly>
                </div>
        
            <div class="col-md-2 mb-3">
            <a href="#" id="btn_remove_line_edit" class="btn btn-outline-danger btn_remove_line_edit btn-circle" data-modif = "modification" data-id_prod="${value.id_produit}" data-id="${value.id_unite_produit}" data-val="${value.libelle_unit}"><i class="fas fa-trash icone_field"></i></a>
        
            </div>
        
        </div>
        
        </div>`;

            });
            $('#list_field').html(html)
            $('.btn-valid-edit-unit').attr('data-id_prod', id_prod)
        },
    });

}
let loadProduit = () => {
    $("#table_produit").DataTable().clear().destroy();

    tableProd = $("#table_produit").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
    });

    $.ajax({
        url: urlProd,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_PRODUIT: "SELECT_PRODUIT" },
        success: function (response) {
            let quantite = 0
            $.each(response, function (index, val) {

                let action = `<button class="btn btn-outline-info btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Actions
            </button>
            <div class="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton" style="">
            <a class="dropdown-item" id="edit_prod" href="#" data-id='${val.id_prod}' data-libelle='${val.libelle_prod}'>Modifier </a>
            <a class="dropdown-item" id="edit_unit" href="#" data-id='${val.id_prod}' data-libelle='${val.libelle_prod}'>Modifier unité</a>
            <a class="dropdown-item" id="delete_prod" href="#" data-id='${val.id_prod}' data-libelle='${val.libelle_prod}' data-image='${val.image_prod}'>Supprimer</a>
            </div>`;
                if (val.quantite_stock == 0) {
                    quantite = "indisponible"
                } else {
                    if (val.quantite_stock > 1) {
                        quantite = val.quantite_stock + ' ' + val.libelle_unit + 's'
                    } else {
                        quantite = val.quantite_stock + ' ' + val.libelle_unit
                    }
                }
                tableProd.row.add([index + 1, val.libelle_prod, quantite, action]);
            });
            tableProd.draw();
        },
    });
};

const initialise_multi_field = () => {
    $('.numberUnit').attr("readOnly", "readOnly")
    $('.icone_field').addClass('fa-trash');
    $('.icone_field').removeClass('fa-check');
}

const fillSelectUnit = () => {
    $.ajax({
        url: urlUnit,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_UNIT: "SELECT_UNIT" },
        success: (response) => {
            let toHtml = `<option value="" selected disabled>Selectionner une unité</option>`
            $.each(response, function (index, val) {
                toHtml += `<option value="${val.id}">${val.libelle_unit}</option>`
            })
            $("#unit").html(toHtml)
        }
    })
}

const fillArray = function (field) {
    field = "";
    storage.forEach(function (value) {
        field += `<div class="form-group">
        <div class="form-row align-items-center">
            <div class="col-md-5 mb-3">
        <!-- Input type text -->
            <input type="text" class="form-control valUnit" data-id="${value.unite}" value="${value.textUnit}" name="valUnit" id="valUnit"  readOnly>
                </div>
        
            <div class="col-md-5 mb-3">
        <!-- Input type text -->
            <input type="text" class="form-control numberUnit" value="${value.number}" name="numberUnit" id="numberUnit" placeholder="quantité" readOnly>
                </div>
        
            <div class="col-md-2 mb-3">
            <a href="#" id="btn_remove_line" class="btn btn-outline-danger btn_remove_line btn-circle" data-val="${value.textUnit}"><i class="fas fa-trash icone_field"></i></a>
        
            </div>
        
        </div>
        
        </div>`;
    });
    $("#list_field").html(field);
};

$(function () {
    loadProduit()
    $(document).on("click", "#add_product", function () {
        $.confirm({
            columnClass: "large",
            title: 'Ajouter une produit',
            content: '' +
                `<div class="widget-content widget-content-area">
                <form class="simple-example" enctype="multipart/form-data" novalidate>
                <!-- columns -->
            <div class="col-md-12 mb-3">
        <!-- Input type text -->
            <label for="libelle_prod">Libelle produit *</label>
            <input type="text" class="form-control form-control-sm obligatoire" name="libelle_prod" id="libelle_prod" required>
                </div>
        <div class="col-md-12 pl-0 ml-2 mb-2">
        <label for="unite_vente">Unité(s) de vente *</label>
        </div>
        <!-- columns -->
        <div class="form-group ml-2">
        <div class="form-row align-items-center">
            <div class="col-5 mb-3">
        <!-- Input type text -->
            <select class="form-control form-control-sm unit" name="unit" id="unit"> </select>
                </div>
                <div class="col-5 mb-3">
        <!-- Input type text -->
        <input type="text" id="number" class="form-control form-control-sm" placeholder="quantité" value="" />
                </div>
        
            <div class="col-md-2 col-sm-2 mb-3">
        <!-- Input type text -->
            <a href="#" id="btn-valid-unit" class="btn btn-sm btn-success btn-valid-unit btn-circle"><i class="fas fa-check"></i></a>
                </div>
        
        </div>
        
        </div>
        
        <!-- Multiple field -->
        <div id="list_field" class = "list_field">
        
</div>
        <!-- Input type text -->
        <div class="form-group ml-2">
        <div class="form-row align-item-center">
        <div class="col-md-4 mb-4">
        <label>Stockable</label>
        <div>
            <div class="custom-control custom-radio custom-control-inline">
                <input class="custom-control-input Stockable" type="radio" name="Stockable" id="oui" value="1" checked>
                <label class="custom-control-label" for="oui">Oui</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
                <input class="custom-control-input Stockable" type="radio" name="Stockable" id="non" value="0">
                <label class="custom-control-label" for="non">Non</label>
            </div>
        </div>
        </div>
        <div class="col-md-8 mb-3">
            <label for="quantite_stock">Quantité en stock *</label>
            <input type="text" style="width:70%" class="form-control form-control-sm obligatoire" name="quantite_stock" id="quantite_stock" >
        </div>
        </div>
        </div>
              <div class="col-md-12 mb-4">
              <div class="form-group">
            <label for="image_prod">Image Produit</label>
            <input type="file" class="form-control form-control-sm mb-2" name="image_prod" id="imgInp" placeholder="file">
          <img src="./img/default_homme.png" id="blah" accept="image/png, image/jpeg" src="#" alt="Inserer une image" />
        </div>
        </div>
              </div>
              </form>
              </div>`,
            buttons: {
                formSubmit: {
                    text: 'Enregistrer',
                    btnClass: 'btn-blue',
                    action: function () {

                        if (storage.length != 0) {
                            // To check that it existe an unit with quantity 1
                            let checkOne = storage.find((s) => s.number == 1)
                            if (checkOne) {
                                storage = JSON.stringify(storage)
                                $.confirm({
                                    content: function () {
                                        var formulaire = $(".simple-example")[0];
                                        var formData = new FormData(formulaire);

                                        formData.append("ADD_EDIT", "ADD_EDIT");
                                        formData.append("listOfUnit", storage);
                                        var self = this;
                                        return $.ajax({
                                            url: urlProd,
                                            method: "POST",
                                            data: formData,
                                            cache: false,
                                            processData: false,
                                            contentType: false,
                                        })
                                            .done(function (response) {
                                                storage = []
                                                if (response.indexOf("success") > -1) {
                                                    self.close();
                                                    showSuccedWal("Information modifiée avec succès");
                                                    loadProduit()
                                                } else {
                                                    self.close();
                                                    showErrorWal(response);
                                                    loadProduit()
                                                }
                                            })
                                            .fail(function () {
                                                self.setContent("Something went wrong.");
                                            });
                                    },
                                });
                            } else {
                                showWarningWal("Vous devez au moins ajouter une unité principale (quantité = 1)")
                                storage = []
                            }

                        } else {
                            showWarningWal("Vous devez au moins ajouter une unité de vente")
                        }

                    }
                },
                cancel: function () {
                    //close
                },
            },
            onContentReady: function () {
                imgInp.onchange = evt => {
                    const [file] = imgInp.files
                    if (file) {
                        blah.src = URL.createObjectURL(file)
                    }
                }
                // bind to events
                var jc = this;
                this.$content.find('form').on('submit', function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger('click'); // reference the button and click it
                });
            },
            onOpenBefore: function () {
                fillSelectUnit()
            }
        });
    })

    $(document).on("change", ".Stockable", function () {

        if ($(this).val() == 1) {
            console.log("OUiiii");
            $("#quantite_stock").removeAttr("disabled")
            $("#quantite_stock").addClass("obligatoire")
        } else {
            console.log("Nonnnnn");
            $("#quantite_stock").attr("disabled", "disabled")
            $("#quantite_stock").removeClass("obligatoire")
            $("#quantite_stock").val("")
        }
    })

    $(document).on("click", "#btn-valid-unit", function () {
        let textSelected = $("#unit option:selected").text();
        let valSelected = $("#unit option:selected").val();
        let number = $("#number").val();
        if (number) {
            if ($(this).data('id_unite_produit')) {
                let id_unite_produit = $(this).data('id_unite_produit');
                console.log(id_unite_produit);
            }
            $('#number').val("")
            if (storage == "") {
                storage.push({
                    unite: valSelected,
                    textUnit: textSelected,
                    number: number,
                });
            } else {
                let existe = storage.find((s) => s.textUnit === textSelected);
                if (existe) {
                    console.log("existe");
                } else {
                    storage.push({
                        unite: valSelected,
                        textUnit: textSelected,
                        number: number,
                    });
                }
            }
        }
        // function to fill the multified
        fillArray(toHtml);
    });

    $(document).on("click", ".btn_remove_line", function () {
        let value = $(this).data("val");
        var index = storage.findIndex(function (s) {
            return s.textUnit === value;
        });
        storage.splice(index, 1);
        fillArray(toHtml);
    });



    // edit product on click btn edit_prod
    $(document).on('click', "#edit_prod", function () {
        const id_prod = $(this).data('id')
        const libelle_prod = $(this).data('libelle')
        $.confirm({
            columnClass: "large",
            title: "Modifier l'unité " + libelle_prod,
            content:
                '' +
                `<div class="widget-content widget-content-area">
                <form class="simple-example" enctype="multipart/form-data" novalidate>
                <!-- columns -->
            <div class="col-md-12 mb-3">
        <!-- Input type text -->
            <label for="libelle_prod">Libelle produit *</label>
            <input type="text" class="form-control form-control-sm obligatoire" name="libelle_prod" id="libelle_prod" required>
                </div>
        <!-- Input type text -->
        <div class="form-group">
        <div class="form-row align-item-center">
        <div class="col-md-4 mb-4">
        <label>Stockable</label>
        <div>
            <div class="custom-control custom-radio custom-control-inline">
                <input class="custom-control-input Stockable" type="radio" name="Stockable" id="oui" value="1" checked>
                <label class="custom-control-label" for="oui">Oui</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
                <input class="custom-control-input Stockable" type="radio" name="Stockable" id="non" value="0">
                <label class="custom-control-label" for="non">Non</label>
            </div>
        </div>
        </div>
        <div class="col-md-8 mb-3">
            <label for="quantite_stock">Quantité en stock *</label>
            <input type="text" style="width:70%" class="form-control form-control-sm obligatoire" name="quantite_stock" id="quantite_stock" >
        </div>
        </div>
        </div>
              <div class="col-md-12 mb-4">
              <div class="form-group">
            <label for="image_prod">Image Produit</label>
            <input type="file" class="form-control form-control-sm mb-2" name="image_prod" id="imgInp" placeholder="file">
          <img src="./img/default_homme.png" id="blah" accept="image/png, image/jpeg" src="#" alt="Inserer une image" />
        </div>
        </div>
              </div>
              </form>
              </div>`,
            buttons: {
                valider: {
                    text: "Modifier",
                    btnClass: "btn-blue",
                    action: function () {
                        storage = JSON.stringify(storage)
                        $.confirm({
                            content: function () {
                                var self = this;
                                var formulaire = $(".simple-example")[0];
                                var formData = new FormData(formulaire);

                                formData.append("ADD_EDIT", "ADD_EDIT");
                                formData.append("id_prod", id_prod);
                                return $.ajax({
                                    url: urlProd,
                                    method: 'post',
                                    data: formData,
                                    cache: false,
                                    processData: false,
                                    contentType: false,
                                }).done(function (response) {
                                    console.log(storage);
                                    if (response.indexOf("success") > -1) {
                                        self.close();
                                        showSuccedWal("Information enregistrée");
                                        loadProduit();
                                    } else {
                                        self.close();
                                        showErrorWal(response);
                                        loadProduit();
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    },
                },
                annuler: function () {
                    //close
                    storage = []
                },
            },
            onContentReady: function () {

                // bind to events
                this.$content.find("form").on("submit", function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger("click"); // reference the button and click it
                });
            },
            onOpenBefore: function () {
                $.confirm({
                    content: function () {
                        var self = this;
                        return $.ajax({
                            url: urlProd,
                            dataType: "JSON",
                            method: "POST",
                            data: { SELECT_PRODUIT: "SELECT_PRODUIT", id_prod: id_prod },
                        }).done(function (response) {
                            self.close();
                            fillSelectUnit()
                            // console.log(response);
                            let value = response[0];
                            nombreLigne = value.nombreLigne
                            if (value.quantite_stock == 0) {
                                $('#non').attr("checked", "checked")
                                $("#quantite_stock").attr("disabled", "disabled")
                            } else {
                                $('#oui').attr("checked", "checked")
                                $("#quantite_stock").val(value.quantite_stock)
                            }
                            console.log(storage);
                            $('#libelle_prod').val(value.libelle_prod)
                            if (!value.image_prod) {
                                $("#blah").attr('src', './img/default_homme.png')
                            } else {
                                $("#blah").attr('src', './upload/produit/' + value.image_prod + '')
                            }

                        });
                    },
                });
            },
        });
    })

    $(document).on('dblclick', '.numberUnit', function () {
        initialise_multi_field()

        let value_field = $(this).parent().parent().find('.valUnit').val();

        $(this).removeAttr("readOnly")
        $(this).parent().parent().find('.icone_field').removeClass('fa-trash');
        $(this).parent().parent().find('.icone_field').addClass('fa-check');

        $(this).parent().parent().find('a').removeClass('btn_remove_line');
        if ($(this).data('modif')) {
            $(this).parent().parent().find('a').removeClass('btn_remove_line_edit');
        }
        $(this).parent().parent().find('a').addClass('edit_a_field');

        $(this).parent().parent().find('.edit_a_field').attr('data-id', value_field)
    })
    $(document).on("click", ".edit_a_field", function () {
        initialise_multi_field()

        if ($(this).parent().parent().find('.numberUnit').data('modif')) {
            let id = $(this).parent().parent().find('.numberUnit').data('id')
            let id_prod = $(this).data('id_prod')
            let quantite_unit = $(this).parent().parent().find('.numberUnit').val()

            $.confirm({
                content: function () {
                    var self = this;
                    return $.ajax({
                        url: urlProd,
                        method: 'post',
                        data: { UPDATE_UNIT: "UPDATE_UNIT", id: id, quantite_unit: quantite_unit }
                    }).done(function (response) {
                        if (response.indexOf("success") > -1) {
                            self.close();
                            showSuccedWal("Unité modifier avec success");
                            loadEditUnit(id_prod);
                        } else {
                            self.close();
                            showErrorWal(response);
                            loadEditUnit(id_prod);
                        }

                    }).fail(function () {
                        self.setContent('Something went wrong.');
                    });
                }
            });

            $(this).addClass("btn_remove_line_edit")
            $(this).removeClass("edit_a_field")
        } else {
            let value = $(this).parent().parent().find('.numberUnit').val()
            let libelle = $(this).data('id')
            console.log(libelle);
            let index = storage.findIndex(function (l) {
                return l.textUnit == libelle
            })
            console.log(index);
            if (storage[index].number != value) {
                storage[index].number = value
                console.log(storage);
            }
            $(this).addClass("btn_remove_line")
            $(this).removeClass("edit_a_field")
        }




    })

    $(document).on('click', "#delete_prod", function () {
        const id_prod = $(this).data('id')
        const libelle_prod = $(this).data('libelle')
        const image_prod = $(this).data('image')
        $.confirm({
            title: `Supprimer le produit "${libelle_prod}"`,
            content: `Cette action supprimera le produit et tous ce qui va avec, voulez-vous vraiment supprimer cette produit?`,
            type: 'red',
            typeAnimated: true,
            buttons: {
                Supprimer: {
                    text: 'Supprimer',
                    btnClass: 'btn-red',
                    action: function () {
                        $.confirm({
                            content: function () {
                                var self = this;
                                return $.ajax({
                                    url: urlProd,
                                    method: 'POST',
                                    data: { DELETE_PROD: 'DELETE_PROD', id_prod: id_prod, image_prod: image_prod }
                                }).done(function (response) {
                                    if (response.indexOf("success") > -1) {
                                        self.close();
                                        showSuccedWal("Suppression éfféctuer");
                                        loadProduit();
                                    } else {
                                        self.close();
                                        showErrorWal("Erreur de suppression");
                                        loadProduit();
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    }
                },
                close: function () {
                }
            }
        });

    })




    // edit unit of a product
    $(document).on("click", ".btn_remove_line_edit", function () {
        const id_delete = $(this).data("id")
        const libelle_unit = $(this).data("val")
        const id_prod = $(this).data('id_prod')
        $.confirm({
            title: `Supprimer l'unité "${libelle_unit}"`,
            content: `Cette action est irreversible,Voulez-vous vraiment supprimer cette unité?`,
            type: 'red',
            typeAnimated: true,
            buttons: {
                Supprimer: {
                    text: 'Supprimer',
                    btnClass: 'btn-red',
                    action: function () {
                        $.confirm({
                            content: function () {
                                var self = this;
                                return $.ajax({
                                    url: urlProd,
                                    method: 'POST',
                                    data: { DELETE_UNIT: 'DELETE_UNIT', id_delete: id_delete, id_prod: id_prod }
                                }).done(function (response) {
                                    if (response.indexOf("success") > -1) {
                                        self.close();
                                        showSuccedWal("Suppression éfféctuer");
                                        loadEditUnit(id_prod);
                                    } else {
                                        self.close();
                                        showErrorWal("Erreur de suppression");
                                        loadEditUnit(id_prod);
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    }
                },
                close: function () {
                }
            }
        });
    })

    $(document).on("click", ".btn-valid-edit-unit", function () {
        const id_prod = $(this).data('id_prod')
        const id_unit = $("#unit option:selected").val()
        const quantite_unit = $("#number").val()
        if (quantite_unit) {
            $.confirm({
                content: function () {
                    var self = this;
                    return $.ajax({
                        url: urlProd,
                        method: 'POST',
                        data: { INSERT_UPDATE_UNIT: 'INSERT_UPDATE_UNIT', id_prod: id_prod, id_unit: id_unit, quantite_unit: quantite_unit }
                    }).done(function (response) {
                        if (response.indexOf("success") > -1) {
                            self.close();
                            showSuccedWal("Suppression éfféctuer");
                            loadEditUnit(id_prod);
                        } else {
                            self.close();
                            showErrorWal(response);
                            loadEditUnit(id_prod);
                        }
                    }).fail(function () {
                        self.setContent('Something went wrong.');
                    });
                }
            });
        }


    })

    $(document).on('click', "#edit_unit", function () {
        const libelle = $(this).data('libelle')
        const id = $(this).data('id')
        $.confirm({
            columnClass: "large",
            title: 'Modifier l\'unité "' + libelle + '"',
            content: '' +
                `<div class="col-md-12 pl-0 mb-1">
                <label for="unite">Unité(s) de vente *</label>
                </div>
                <!-- columns -->
                <div class="form-group">
                <div class="form-row align-items-center">
                    <div class="col-sm-5 mb-3">
                <!-- Input type text -->
                    <select class="form-control form-control-sm unit" name="unit" id="unit"> </select>
                        </div>
                        <div class="col-sm-5 mb-3">
                <!-- Input type text -->
                <input type="text" id="number" class="form-control form-control-sm" placeholder="quantité" value="" />
                        </div>
                
                    <div class="col-md-2 col-sm-2 mb-3">
                <!-- Input type text -->
                    <a href="#" id="btn-valid-edit-unit" class="btn btn-success btn-valid-edit-unit btn-circle"><i class="fas fa-check"></i></a>
                        </div>
                
                </div>
                
                </div>
                <div id="list_field" class = "list_field">
        
                </div>`,
            buttons: {
                formSubmit: {
                    text: 'Terminé',
                    btnClass: 'btn-blue',
                    action: function () {
                        $.confirm({
                            content: function () {
                                var self = this;
                                return $.ajax({
                                    url: urlProd,
                                    method: 'post',
                                    data: {}
                                }).done(function (response) {
                                    self.close()
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    }
                },

            },
            onContentReady: function () {
                // bind to events
                var jc = this;
                this.$content.find('form').on('submit', function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger('click'); // reference the button and click it
                });
            },
            onOpenBefore: function () {
                fillSelectUnit()
                loadEditUnit(id)
            }
        });

    })

})