
let tableUnit;
let id_unit, libelle_unit;
const urlUnit = "./model/php/DAOUnit.php";
const loadUnit = () => {
    $("#table_unit").DataTable().clear().destroy();

    tableUnit = $("#table_unit").DataTable({
        lengthMenu: [5, 20, 50, 100, 200],
        fixedHeader: true,
    });

    $.ajax({
        url: urlUnit,
        dataType: "JSON",
        method: "POST",
        data: { SELECT_UNIT: "SELECT_UNIT" },
        success: function (response) {
            $.each(response, function (index, val) {
                let action = `<a href="#" class="btn btn-sm btn-warning btn-circle edit_unit" id="edit_unit" data-id='${val.id}' data-libelle='${val.libelle_unit}'><i class="fas fa-edit"></i></a>
                <a href="#" class="btn btn-sm btn-danger btn-circle delete_unit" id="delete_unit" data-id='${val.id}' data-libelle='${val.libelle_unit}'><i class="fas fa-trash"></i></a>`;

                tableUnit.row.add([index + 1, val.libelle_unit, action]);
            });
            tableUnit.draw();
        },
    });
};

$(function () {
    // load table of unité
    loadUnit();
    $(document).on("click", "#add_unit", function () {
        $.confirm({
            title: 'Ajouter une Unité',
            content: '' +
                '<form action="" class="formName">' +
                '<div class="form-group">' +
                '<label>Libelle unités</label>' +
                '<input type="text" class="form-control libelle_unit" id="libelle_unit" required />' +
                '</div>' +
                '</form>',
            buttons: {
                formSubmit: {
                    text: 'Enregistrer',
                    btnClass: 'btn-blue',
                    action: function () {
                        $.confirm({
                            content: function () {
                                var self = this;
                                const libelle = $("#libelle_unit").val()
                                return $.ajax({
                                    url: './model/php/DAOUnit.php',
                                    method: 'post',
                                    data: { ADD_EDIT: "ADD_EDIT", libelle: libelle }
                                }).done(function (response) {
                                    if (response.indexOf("success") > -1) {
                                        self.close();
                                        showSuccedWal("Information enregistrée");
                                        loadUnit();
                                    } else {
                                        self.close();
                                        showErrorWal(response);
                                        loadUnit();
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    }
                },
                annuler: function () {
                    //close
                },
            },
            onContentReady: function () {
                // bind to events
                var jc = this;
                this.$content.find('form').on('submit', function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger('click'); // reference the button and click it
                });
            }

        });
    })

    $(document).on("click", "#edit_unit", function () {
        id_unit = $(this).data("id");
        libelle_unit = $(this).data("libelle");
        console.clear();
        $.confirm({
            columnClass: "large",
            title: "Modifier l'unité " + libelle_unit,
            content:
                '' +
                '<form action="" class="formName">' +
                '<div class="form-group">' +
                '<label>Libelle unités</label>' +
                '<input type="text" class="form-control libelle_unit" id="libelle_unit" required />' +
                '</div>' +
                '</form>',
            buttons: {
                valider: {
                    text: "Modifier",
                    btnClass: "btn-blue",
                    action: function () {
                        const libelle_edit = $('.libelle_unit').val()
                        $.confirm({
                            content: function () {
                                var self = this;
                                const libelle = $("#libelle_unit").val()
                                return $.ajax({
                                    url: './model/php/DAOUnit.php',
                                    method: 'post',
                                    data: { ADD_EDIT: "ADD_EDIT", libelle: libelle, id_unit: id_unit }
                                }).done(function (response) {
                                    if (response.indexOf("success") > -1) {
                                        self.close();
                                        showSuccedWal("Information enregistrée");
                                        loadUnit();
                                    } else {
                                        self.close();
                                        showErrorWal(response);
                                        loadUnit();
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    },
                },
                annuler: function () {
                    //close
                },
            },
            onContentReady: function () {

                // bind to events
                this.$content.find("form").on("submit", function (e) {
                    // if the user submits the form by pressing enter in the field.
                    e.preventDefault();
                    jc.$$formSubmit.trigger("click"); // reference the button and click it
                });
            },
            onOpenBefore: function () {
                $.confirm({
                    content: function () {
                        var self = this;
                        return $.ajax({
                            url: urlUnit,
                            dataType: "JSON",
                            method: "POST",
                            data: { SELECT_UNIT: "SELECT_UNIT", id_unit: id_unit },
                        }).done(function (response) {
                            self.close();
                            // console.log(response);
                            let value = response[0];
                            $("#libelle_unit").val(value.libelle_unit);
                        });
                    },
                });
            },
        });
    });

    $(document).on("click", "#delete_unit", function () {
        id_unit = $(this).data("id");
        libelle_unit = $(this).data("libelle")
        $.confirm({
            title: `Supprimer l'unité "${libelle_unit}"`,
            content: 'Cette action est irreversible,Voulez-vous vraiment supprimer cette unité?',
            type: 'red',
            typeAnimated: true,
            buttons: {
                Supprimer: {
                    text: 'Supprimer',
                    btnClass: 'btn-red',
                    action: function () {
                        $.confirm({
                            content: function () {
                                var self = this;
                                return $.ajax({
                                    url: urlUnit,
                                    method: 'POST',
                                    data: { DELETE_UNIT: "DELETE_UNIT", id_unit: id_unit }
                                }).done(function (response) {
                                    if (response.indexOf("success") > -1) {
                                        self.close();
                                        showSuccedWal("Suppression éfféctuer");
                                        loadUnit();
                                    } else {
                                        self.close();
                                        showErrorWal("Erreur de suppression");
                                        loadUnit();
                                    }
                                }).fail(function () {
                                    self.setContent('Something went wrong.');
                                });
                            }
                        });
                    }
                },
                close: function () {
                }
            }
        });
    })
})