<?php

require_once '../../config/connection.php';
require_once 'function.php';

date_default_timezone_set('Africa/Nairobi');

if (isset($_POST['SELECT_USER'])) {
    if (isset($_POST['id_user'])) {
        //Select specific user
        $id_user = $_POST['id_user'];
        $requette = "SELECT * FROM `utilisateur` WHERE `id_user` ='$id_user'";
    } else {
        //select all user
        $requette = "SELECT * FROM utilisateur";
    }
    //Execution of request
    $result = $connection->query($requette);
    $JSON_obj = array();
    if ($result->num_rows>0) {
        while ($row = $result->fetch_assoc()) {
            $JSON_obj[] = $row;
        }
        //Convert the table to JSON
        echo json_encode($JSON_obj);
    }
}

if (isset($_POST['ADD_EDIT'])) {
    $nom_user = $_POST['nom_user'];
    $prenom_user = $_POST['prenom_user'];
    $tel_user = $_POST['tel_user'];
    $sexe_user = $_POST['sexe_user'];
    $date_naiss_user = $_POST['date_naiss_user'];
    $adresse_user = $_POST['adresse_user'];
    $size_image = $_FILES['image_user']['size'];
    $mot_de_passe = sha1($_POST['password']);
    $last_modified_at = date('y-m-d h:i:s');

    if (isset($_POST['id_user'])) {
        $id_user = $_POST['id_user'];
        if ($size_image>0) {
            $image_user =  $_FILES['image_user']['name'] ;
            $temp_location = $_FILES['image_user']['tmp_name'];
            $file_extention = pathinfo($image_user, PATHINFO_EXTENSION);
            $file_extention = strtolower($file_extention);
            $image_name = $id_user.'.'.$file_extention;
            $location = "../../upload/".$image_name;
            // Request to update with image
            $requette = "UPDATE `utilisateur` SET `nom_user`='$nom_user',`prenom_user`='$prenom_user',`tel_user`='$tel_user',`date_naiss_user`='$date_naiss_user',`adresse_user`='$adresse_user',`sexe_user`='$sexe_user',`last_modified_at`='$last_modified_at',`image_user`='$image_name' WHERE `id_user` ='$id_user'";
            if (file_exists($location)) {
                if (unlink($location)) {
                    $connection->query($requette);
                    upload_file($temp_location, $location);
                }
            } else {
                $connection->query($requette);
                upload_file($temp_location, $location);
            }
        } else {
            // Request to update without image

            $requette = "UPDATE `utilisateur` SET `nom_user`='$nom_user',`prenom_user`='$prenom_user',`tel_user`='$tel_user',`date_naiss_user`='$date_naiss_user',`adresse_user`='$adresse_user',`sexe_user`='$sexe_user',`last_modified_at`='$last_modified_at' WHERE `id_user` ='$id_user'";
            $connection->query($requette);
            if ($connection->affected_rows>0) {
                success();
            } else {
                echec();
            }
        }
    } else {
        //Add user
        $image_user =  $_FILES['image_user']['name'] ;
        $temp_location = $_FILES['image_user']['tmp_name'];
        $file_extention = pathinfo($image_user, PATHINFO_EXTENSION);
        $file_extention = strtolower($file_extention);
        $maxID = getLastId("utilisateur");
        $image_name = $maxID.'.'.$file_extention;
        $location = "../../upload/".$image_name;
        $created_date = date('y-m-d h:i:s');

        $requette = "INSERT INTO `utilisateur`( `nom_user`, `prenom_user`, `tel_user`, `date_naiss_user`, `adresse_user`,`sexe_user`, `image_user`,`mot_de_passe`, `created_at`) VALUES ('$nom_user','$prenom_user','$tel_user','$date_naiss_user','$adresse_user','$sexe_user','$image_name','$mot_de_passe','$created_date')";
        $check = "SELECT * FROM `utilisateur` where `nom_user` = '$nom_user' and `prenom_user` = '$prenom_user'";
        $checkIfExist = $connection->query($check);
        // Tester l'existance de linformation (libelle)
        if ($checkIfExist->num_rows>0) {
            echo "Contenu avec le nom existant";
        } else {
            if (!file_exists("../../upload")) {
                mkdir("../../upload");
            }
            if (move_uploaded_file($temp_location, $location)) {
                $connection->query($requette);
                if ($connection->affected_rows>0) {
                    success();
                } else {
                    echec();
                }
            } else {
                echec();
            }
        }
    }
}
if (isset($_POST['DELETE_USER'])) {
    $id_user = $_POST['id_user'];
    $image_user = $_POST['image_user'];
    $image_user ="../../upload/".$image_user;
    $requette = "DELETE FROM `utilisateur` WHERE id_user = '$id_user'";
    $connection -> query($requette);
    if ($connection->affected_rows>0) {
        if (file_exists($image_user)) {
            if (unlink($image_user)) {
                success();
            } else {
                echo "impossible de supprimmer l'image";
            }
        } else {
            success();
        }
    } else {
        erreur();
    }
}

if (isset($_POST["UPDATE_PASS"])) {
    $id_user = $_POST['id_user'];
    $old_pass=sha1($_POST["old_pass"]);
    $new_pass_1 = $_POST["new_pass_1"];
    $new_pass_2 = $_POST["new_pass_2"];
    $crypt_pass = sha1($new_pass_1);

    $check_pass_exist = "SELECT * from utilisateur where `mot_de_passe` = '$old_pass' ";
    $resultat = $connection->query($check_pass_exist);
    if ($resultat->num_rows>0) {
        if ($new_pass_1==$new_pass_2) {
            $requette = "update utilisateur set `mot_de_passe` = '$crypt_pass' where `id_user` = '$id_user'";
            $connection ->query($requette);
            if ($connection->affected_rows>0) {
                // session_start();
                // $_SESSION['user']['mdp'] = "$crypt_pass";
                success();
            } else {
                echec();
            }
        } else {
            echo("mot de passe different");
        }
    } else {
        echo("mot de passe incorrecte !!");
    }
    // old_pass new_pass_1
}
