<?php

require_once '../../config/connection.php';
require_once 'function.php';
date_default_timezone_set('Africa/Nairobi');

if (isset($_POST['SELECT_ACHAT'])) {
    if (isset($_POST['id'])) {
        //Select specific achat
        $id = $_POST['id'];
        $requette = "SELECT A.`date_achat`, A.totale_achat,B.libelle_achat,B.motif_achat,B.unite_achat,B.quantite_achat,B.total_achat, C.prenom_user FROM `achat_groupe` A LEFT JOIN `achat_detail` B on A.id_achat_groupe = B.id_achat_groupe LEFT JOIN `utilisateur` C ON A.acteur = C.id_user WHERE A.id_achat_groupe = '$id' ORDER BY B.libelle_achat; ";
    } else {
        //select all achat
        $requette = "SELECT A.id_achat_groupe,A.date_achat,A.totale_achat,A.acteur, B.prenom_user FROM `achat_groupe` A LEFT JOIN `utilisateur` B ON A.acteur = B.id_user ;";
    }
    //Execution of request
    $result = $connection->query($requette);
    $JSON_obj = array();
    if ($result->num_rows>0) {
        while ($row = $result->fetch_assoc()) {
            $JSON_obj[] = $row;
        }
        //Convert the table to JSON
        echo json_encode($JSON_obj);
    }
}
if (isset($_POST["INSERT_ACHAT"])) {
    if($_POST['date_achat']) {
        $date_achat = strval($_POST['date_achat']) ;
        $heure_achat = strval($_POST['heure_achat']);
        $date_achat .= ' '. $heure_achat.':00';
    } else {
        $date_achat = date('y-m-d h:i:s');
    }
    $list_achat = $_POST['list_achat'];
    $totale_achat_groupe = 0;
    $id_user = $_POST['id_user'];
    $list_achat = json_decode($list_achat);
    for ($i=0;$i<count($list_achat);$i++) {
        $totale_achat_groupe+= $list_achat[$i]->quantite * $list_achat[$i]->prix_unit;
    }
    $id_achat_groupe = getLastId("achat_groupe");

    $insert_achat_groupe = "INSERT INTO `achat_groupe`(`date_achat`,`totale_achat`,`acteur`) VALUES ('$date_achat','$totale_achat_groupe','$id_user')";
    $connection->begin_transaction();
    $connection->autocommit(false);
    $connection->query($insert_achat_groupe);

    foreach ($list_achat as $key => $value) {
        $totale = $value->quantite*$value->prix_unit;
        $insert_achat_detail = "INSERT INTO `achat_detail`( `id_achat_groupe`, `libelle_achat`, `motif_achat`,`date_achat`, `quantite_achat`, `unite_achat`,`prix_unit`, `total_achat`) VALUES ('$id_achat_groupe','$value->libelle_achat','$value->motif','$date_achat','$value->quantite','$value->unite','$value->prix_unit','$totale')";
        $connection->query($insert_achat_detail);
    }
    if ($connection->commit()) {
        success();
    } else {
        echec();
    }
}
