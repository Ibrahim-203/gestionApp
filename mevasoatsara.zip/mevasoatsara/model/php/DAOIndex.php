<?php

require_once '../../config/connection.php';
require_once 'function.php';

if (isset($_POST["SELECT_STATISTIC"])) {
    if (isset($_POST["chart"])) {
        $requette = "SELECT (SELECT SUM(totale) FROM `vente_detail` WHERE created_at like '%-01-%') as `janvier` , (SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-02-%') as `fevrier`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-03-%') as `mars`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-04-%') as `avril`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-05-%') as `mai`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-06-%') as `juin`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-07-%') as `juillet`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-08-%') as `aout`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-09-%') as `septembre`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-10-%') as `octobre`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-11-%') as `novembre`,(SELECT SUM(totale)  FROM `vente_detail` WHERE created_at like '%-12-%') as `decembre`;";
    } else {
        $requette ="SELECT  (SELECT COUNT(*) FROM   vente_groupe) AS vente,
        (SELECT COUNT(*) FROM   produit) AS produit,
        ( SELECT COUNT(*) FROM   utilisateur ) AS user,
        ( SELECT COUNT(*) FROM   achat_groupe ) AS achat";
    }

    $result = $connection->query($requette);
    $JSON_obj = array();
    if ($result->num_rows>0) {
        while ($row = $result->fetch_assoc()) {
            $JSON_obj[] = $row;
        }
        //Convert the table to JSON
        echo json_encode($JSON_obj);
    }
}
