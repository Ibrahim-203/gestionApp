<?php

require_once '../../config/connection.php';
require_once 'function.php';
date_default_timezone_set('Africa/Nairobi');
if (isset($_POST["INSERT_VENTE"])) {
    $list_vente = $_POST['list_vente'];
    $nom_client = $_POST['nom_client'];
    $adresse_client = $_POST['adresse_client'];
    $tel_client = $_POST['tel_client'];
    $totale_vente_groupe = 0;
    $id_user = $_POST['id_user'];
    if($_POST['date_vente']) {

        $date_vente = strval($_POST['date_vente']) ;
        $heure_vente = strval($_POST['heure_vente']);
        $date_vente .= ' '. $heure_vente.':00';
    } else {
        $date_vente = date('y-m-d h:i:s');
    }
    $list_vente = json_decode($list_vente);
    for ($i=0;$i<count($list_vente);$i++) {
        $totale_vente_groupe+= $list_vente[$i]->quantite * $list_vente[$i]->prix_unit;
    }
    $id_vente_groupe = getLastId("vente_groupe");



    $insert_vente_groupe = "INSERT INTO `vente_groupe`( `proprietaire`, `adresse_proprietaire`, `tel_proprietaire`, `totale_vente`,`date_vente`) VALUES (' $nom_client','$adresse_client',' $tel_client',' $totale_vente_groupe','$date_vente')";
    $connection->begin_transaction();
    $connection->autocommit(false);
    $connection->query($insert_vente_groupe);

    foreach ($list_vente as $key => $value) {
        $totale = $value->quantite*$value->prix_unit;
        $insert_vente_detail = "INSERT INTO `vente_detail`( `id_vente_groupe`, `produit_vendu`, `unite_vente`, `quantite`, `prix_unitaire`, `totale`,`created_at`, `created_by`) VALUES ('$id_vente_groupe','$value->id_produit','$value->id_unite_vente','$value->quantite','$value->prix_unit','$totale','$date_vente','$id_user')";
        $connection->query($insert_vente_detail);
    }
    if ($connection->commit()) {
        success();
    } else {
        echec();
    }
}

if (isset($_POST['SELECT_VENTE'])) {
    if (isset($_POST['id'])) {
        //Select specific categorie
        $id = $_POST['id'];
        $requette = "SELECT V.`id_vente_groupe`,`proprietaire`,`tel_proprietaire`,`adresse_proprietaire` ,`date_vente`, `libelle_prod`, `libelle_unit`,`etat_vente_groupe`,`quantite`,`totale` FROM `vente_groupe` V LEFT JOIN `vente_detail` D ON V.id_vente_groupe = D.id_vente_groupe LEFT JOIN `produit` P ON P.id_prod = D.produit_vendu LEFT JOIN `unite` U ON U.id = D.unite_vente WHERE V.id_vente_groupe = '$id' ";
    } else {
        //select all categorie
        $requette = "SELECT * FROM `vente_groupe` where `status` = 1 order by `date_vente`";
    }
    //Execution of request
    $result = $connection->query($requette);
    $JSON_obj = array();
    if ($result->num_rows>0) {
        while ($row = $result->fetch_assoc()) {
            $JSON_obj[] = $row;
        }
        //Convert the table to JSON
        echo json_encode($JSON_obj);
    }
}

if(isset($_POST['UPDATE_ETAT'])) {
    $id = $_POST['id'];
    $etat = $_POST['value'];
    $requette = "UPDATE `vente_groupe` SET `etat_vente_groupe`='$etat' where `id_vente_groupe` = '$id'";
    $connection->query($requette);
    if ($connection->affected_rows>0) {
        echo "success";
    } else {
        echo "erreur";
    }
}

if(isset($_POST['DELETE_VENTE'])) {
    $id= $_POST['id'];
    $requette = "UPDATE `vente_groupe` SET `status`= 0 where `id_vente_groupe` = '$id'";
    $connection->query($requette);
    if ($connection->affected_rows>0) {
        echo "success";
    } else {
        echo "erreur";
    }
}
