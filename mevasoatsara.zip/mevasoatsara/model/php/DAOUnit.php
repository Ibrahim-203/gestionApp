<?php

require_once '../../config/connection.php';

if (isset($_POST['SELECT_UNIT'])) {
    if (isset($_POST['id_unit'])) {
        //Select specific categorie
        $id_unit = $_POST['id_unit'];
        $requette = "SELECT * FROM unite WHERE `id` ='$id_unit'";
    } else {
        //select all categorie
        $requette = "SELECT * FROM unite";
    }
    //Execution of request
    $result = $connection->query($requette);
    $JSON_obj = array();
    if ($result->num_rows>0) {
        while ($row = $result->fetch_assoc()) {
            $JSON_obj[] = $row;
        }
        //Convert the table to JSON
        echo json_encode($JSON_obj);
    }
}


if (isset($_POST['ADD_EDIT'])) {
    $libelle = $_POST['libelle'];
    $check = "SELECT * FROM unite where `libelle_unit` = '$libelle'";
    $checkIfExist = $connection->query($check);
    // Tester l'existance de l'information (libelle)
    if ($checkIfExist->num_rows>0) {
        echo "Contenu avec le nom existant";
    } else {
        if (isset($_POST['id_unit'])) {
            $id_unit = $_POST['id_unit'];
            $requette = "UPDATE `unite` SET `libelle_unit`='$libelle' WHERE `id`='$id_unit'";
        } else {
            date_default_timezone_set('Africa/Nairobi');
            $date = date('y-m-d h:i:s');
            $requette = "INSERT INTO unite (`libelle_unit`,`created_at`) VALUES ('$libelle','$date')";
        }
        $connection->query($requette);
        if ($connection->affected_rows>0) {
            echo "success";
        } else {
            echo "erreur";
        }
    }
}

if (isset($_POST['DELETE_UNIT'])) {
    $id_unit = $_POST['id_unit'];

    $requette = "DELETE FROM unite where `id`= '$id_unit'";
    $connection ->query($requette);
    if ($connection->affected_rows>0) {
        echo "success";
    } else {
        echo "Error";
    }
}