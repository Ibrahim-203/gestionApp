<?php

require_once '../../config/connection.php';
require_once 'function.php';

date_default_timezone_set('Africa/Nairobi');
if (isset($_POST["SELECT_PRODUIT"])) {
    if (isset($_POST["id_prod"])) {
        $id_prod = $_POST["id_prod"];
        $requette = "SELECT `id_unite_produit`,`id_prod`, `libelle_prod`,`id_unit`, `image_prod`,`quantite_stock`, `libelle_unit`, `quantite_unit`,(SELECT count(*) from `unite_produit` where `id_produit` = '$id_prod' ) as nombreLigne FROM `produit` P LEFT JOIN `unite_produit` I ON I.id_produit = P.id_prod LEFT JOIN `unite` U ON U.id = I.id_unit WHERE P.id_prod = '$id_prod' ";
    } elseif(isset($_POST["APPRO"])) {
        $requette = "SELECT `id_prod`,`libelle_prod`, `quantite_stock`, `libelle_unit` FROM `produit` P LEFT JOIN `unite_produit` U on P.id_prod = U.id_produit LEFT JOIN `unite` O ON O.id = U.id_unit WHERE `stock` = 1 and U.quantite_unit = 1";
    } else {
        $requette = "SELECT `id_prod`,`libelle_prod`, `quantite_stock`,`image_prod`, `libelle_unit`,`stock` FROM `produit` P LEFT JOIN `unite_produit` U on P.id_prod = U.id_produit LEFT JOIN `unite` O ON O.id = U.id_unit WHERE U.quantite_unit = 1  ";
    }

    $result = $connection->query($requette);
    $JSON_obj = array();
    if ($result->num_rows>0) {
        while ($row = $result->fetch_assoc()) {
            $JSON_obj[] = $row;
        }
        //Convert the table to JSON
        echo json_encode($JSON_obj);
    } else {
        echo "No result";
    }
}

if (isset($_POST['ADD_EDIT'])) {
    $libelle_prod = $_POST['libelle_prod'];
    $Stockable = $_POST['Stockable'];
    if ($Stockable==1) {
        $quantite_stock = $_POST['quantite_stock'];
    } else {
        $quantite_stock = 0;
    }
    $unit = json_decode($_POST['listOfUnit']);
    $size_image = $_FILES['image_prod']['size'];
    $last_modified_at = date('y-m-d h:i:s');

    if (isset($_POST['id_prod'])) {
        $id_prod = $_POST['id_prod'];
        $nombreLigne = $_POST['nombreLigne'];
        if ($size_image>0) {
            $image_prod =  $_FILES['image_prod']['name'] ;
            $temp_location = $_FILES['image_prod']['tmp_name'];
            $file_extention = pathinfo($image_prod, PATHINFO_EXTENSION);
            $file_extention = strtolower($file_extention);
            $image_name = $id_prod.'.'.$file_extention;
            $location = "../../upload/".$image_name;
            // Request to update with image
            $requette = "UPDATE `produit` SET `libelle_prod`='$libelle_prod',`quantite_stock`='$quantite_stock',`last_modified_at`='$last_modified_at',`image_prod`='$image_name' WHERE `id_prod` ='$id_prod'";
            if (file_exists($location)) {
                if (unlink($location)) {
                    $connection->query($requette);
                    upload_file($temp_location, $location);
                }
            } else {
                $connection->query($requette);
                upload_file($temp_location, $location);
            }
        } else {
            // Request to update without image

            $requette = "UPDATE `produit` SET `libelle_prod`='$libelle_prod',`quantite_stock`='$quantite_stock',`last_modified_at`='$last_modified_at' WHERE `id_prod` ='$id_prod'";
            $connection->query($requette);

            if ($connection->affected_rows>0) {
                success();
            } else {
                error();
            }
        }
    } else {
        //Add product |-- Last modified (requette d'insertion)--|
        $image_prod =  $_FILES['image_prod']['name'] ;
        $temp_location = $_FILES['image_prod']['tmp_name'];
        $file_extention = pathinfo($image_prod, PATHINFO_EXTENSION);
        $file_extention = strtolower($file_extention);
        $maxID = getLastId("produit");
        $image_name = "";
        $location = "../../upload/produit/".$image_name;
        $created_date = date('y-m-d h:i:s');


        $requette = "INSERT INTO `produit`( `libelle_prod`, `image_prod`, `quantite_stock`, `created_at`,`stock`) VALUES ('$libelle_prod','$image_name','$quantite_stock','$created_date','$Stockable')";


        $check = "SELECT * FROM `produit` where `libelle_prod` = '$libelle_prod'";
        $checkIfExist = $connection->query($check);
        // Tester l'existance de linformation (libelle)
        if ($checkIfExist->num_rows>0) {
            echo "Contenu avec le nom existant";
        } else {
            $id_prod = getLastId("produit");
            if (!file_exists("../../upload/produit")) {
                mkdir("../../upload/produit");
            }
            $connection->begin_transaction();
            $connection->autocommit(false);
            $connection->query($requette);
            foreach ($unit as $u) {
                $insertUnit = "INSERT into `unite_produit` (`id_produit`,`id_unit`,`quantite_unit` ) values ('$maxID','$u->unite','$u->number')";
                $connection ->query($insertUnit);
            }
            if($size_image>0) {
                $image_name = $maxID.'.'.$file_extention;
                if (move_uploaded_file($temp_location, $location)) {
                    if ($connection->commit()) {
                        success();
                    } else {
                        echec();
                    }
                } else {
                    echo "Impossible de déplacer l'image";
                }
            } else {

                if ($connection->commit()) {
                    success();
                } else {
                    echec();
                }
            }

        }
    }
}

if (isset($_POST["DELETE_PROD"])) {
    $id_prod = $_POST['id_prod'];
    $image_prod = $_POST['image_prod'];
    $image_prod ="../../upload/".$image_prod;
    $delete_prod = "DELETE FROM `produit` WHERE id_prod = '$id_prod'";
    $delete_unit = "DELETE FROM `unite_produit` WHERE id_produit = '$id_prod'";
    $connection->begin_transaction();
    $connection->autocommit(false);
    $connection -> query($delete_prod);
    $connection -> query($delete_unit);
    if ($connection->commit()) {
        if (file_exists($image_prod)) {
            if (unlink($image_prod)) {
                success();
            } else {
                echo "impossible de supprimmer l'image";
            }
        } else {
            success();
        }
    } else {
        erreur();
    }
}
// DAO for unit
if (isset($_POST['SELECT_UNIT'])) {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        $requette = "SELECT `id_unite_produit`,`quantite_unit`, `libelle_unit`, `id_produit` FROM `unite_produit`  LEFT JOIN `unite` ON `id_unit` = `id` where `id_produit` = '$id' ";
        $result = $connection->query($requette);
        $JSON_obj = array();
        if ($result->num_rows>0) {
            while ($row = $result->fetch_assoc()) {
                $JSON_obj[] = $row;
            }
            //Convert the table to JSON
            echo json_encode($JSON_obj);
        }
    }
}
if (isset($_POST['DELETE_UNIT'])) {
    $id_delete = $_POST['id_delete'];
    $id_prod = $_POST['id_prod'];

    $requette = "DELETE FROM `unite_produit` WHERE `id_unite_produit` = ' $id_delete' and `id_produit` = '$id_prod'";
    $connection -> query($requette);
    if ($connection->affected_rows>0) {
        success();
    } else {
        erreur();
    }
}

if (isset($_POST['INSERT_UPDATE_UNIT'])) {
    $id_produit = $_POST['id_prod'];
    $id_unit = $_POST['id_unit'];
    $quantite_unit = $_POST['quantite_unit'];

    $check = "SELECT * from `unite_produit` where `id_unit` = '$id_unit'";
    $checkIfExist = $connection->query($check);
    if ($checkIfExist->num_rows>0) {
        echo("Cette unité existe déjà");
    } else {
        $requette = "INSERT INTO `unite_produit` (`id_produit`,`id_unit`,`quantite_unit`) VALUES ('$id_produit','$id_unit','$quantite_unit')";

        $connection ->query($requette);
        if ($connection->affected_rows>0) {
            success();
        } else {
            echec();
        }
    }
}
if (isset($_POST['UPDATE_UNIT'])) {
    $id_unit_produit = $_POST['id'];
    $quantite_unit = $_POST['quantite_unit'];

    $requette = "UPDATE `unite_produit` SET `quantite_unit` = '$quantite_unit' where `id_unite_produit` = '$id_unit_produit'";

    $connection->query($requette);
    if ($connection->affected_rows>0) {
        success();
    } else {
        echec();
    }
}

if(isset($_POST['APPROVISIONNEMENT'])) {
    $quantite = $_POST['quantite'];
    $quantiteAdd = $_POST['quantiteAdd'];
    $newQuantite = $quantite + $quantiteAdd;
    $id_prod = $_POST['id_prod'];
    $last_modified_at = date('y-m-d h:i:s');

    $requette = "UPDATE `produit` SET `quantite_stock` =  '$newQuantite',`last_modified_at`= '$last_modified_at' WHERE `id_prod` =  $id_prod";

    $connection->query($requette);
    if ($connection->affected_rows>0) {
        success();
    } else {
        echec();
    }
}
