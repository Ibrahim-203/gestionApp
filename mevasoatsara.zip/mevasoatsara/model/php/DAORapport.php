<?php

require_once '../../config/connection.php';
require_once 'function.php';

if (isset($_POST["SELECT_REPORT"])) {

    $requette = "SELECT `created_at` FROM `vente_detail` WHERE 1";
    $result = $connection->query($requette);
    $JSON_obj = array();
    if ($result->num_rows>0) {
        while ($row = $result->fetch_assoc()) {
            $JSON_obj[] = $row;
        }
        //Convert the table to JSON
        echo json_encode($JSON_obj);
    }
}
