<?php

$date = "2010-05-22";
$month = date("n", strtotime($date));
var_dump($date);
echo "<br>";
echo $month;
