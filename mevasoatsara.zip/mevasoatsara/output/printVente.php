<?php

header('Content-Type: text/html; charset=utf-8');
session_start();
$connection  = new mysqli("localhost", "root", "", "mevasoatsara");
require_once '../vendor/tcpdf_min/tcpdf.php';

class MYPDF extends TCPDF
{
    //Page header
    /*
    public function Header()
    {
        // Logo
        //$this->Image($image, 10, 10, 25, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        // Set font
        //        $this->SetFont('times', 'B', 16);
        // Title
        //        $this->Cell(0, 15, ' CERTIFICAT DE SCOLARITE ', 0, false, 'C', 0, '', 0, false, 'M', 'M');
    }*/

    // Page footer
    public function Footer()
    {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('times', 'G', 7);
        // Page number
        //        $this->Cell(0, 20, 'Avis important: Il ne peut être délivré qu’un seul exemplaire du présent relevé de notes. Aucun duplicata ne sera fourni.', 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }

    /**
     * @param bool $destroyall
     * @param bool $preserve_objcopy
     */
    public function _destroy($destroyall = false, $preserve_objcopy = false)
    {
        if ($destroyall) {
            unset($this->imagekeys);
        }
        parent::_destroy($destroyall, $preserve_objcopy);
    }
}

$obj_pdf = new MYPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$obj_pdf->SetCreator(PDF_CREATOR);
$obj_pdf->SetAuthor('Mevasoatsara');
$obj_pdf->SetTitle("Liste vente");
$obj_pdf->SetKeywords('TESTE');
$obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);
$obj_pdf->setHeaderFont(array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$obj_pdf->setFooterFont(array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$obj_pdf->SetDefaultMonospacedFont('helvetica');
$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
$obj_pdf->SetMargins(PDF_MARGIN_LEFT, '5', PDF_MARGIN_RIGHT);
$obj_pdf->setPrintHeader(false);
$obj_pdf->setPrintFooter(true);
$obj_pdf->SetAutoPageBreak(true, 10);
$obj_pdf->SetFont('times', '', 13);
$obj_pdf->AddPage();

$id= $_GET['id'];
$query = "SELECT `proprietaire`,`tel_proprietaire`,`adresse_proprietaire` ,`date_vente`,`libelle_prod`,`libelle_unit`, `quantite`,D.`prix_unitaire`, `totale`,US.`nom_user` FROM `vente_detail` D LEFT JOIN `produit` P ON D.produit_vendu = P.id_prod LEFT JOIN `unite` U ON U.id = D.unite_vente LEFT JOIN `vente_groupe` G ON D.id_vente_groupe = G.id_vente_groupe LEFT JOIN `utilisateur` US ON US.id_user = D.created_by WHERE D.id_vente_groupe = '$id'; ";

$rst = $connection->query($query);
$i=0;
$factures = $rst->fetch_all();

$content = '<table style="width:75%" >
<tbody>
<tr>
<td style="width:60%">
<img style="width:100px;height:100px" src="../img/Logo.png">
</td>
<td style="width:75%">
<span style="text-align:center">
<span style="font-weight:bold;font-size:20px">Mevasoatsara</span><br>
<span>" Produit saine et à porté de tous "</span>
</span><br>
<span>&nbsp;&nbsp;Adresse : Andalohesy CR Antsalaka Diego II</span><br>
<span>&nbsp;&nbsp;NIF : 3004154614 </span><br>
<span>&nbsp;&nbsp;STAT : 01131712020001426 </span><br>
<span>&nbsp;&nbsp;Téléphone : 0320751741 - 0341087613</span><br>
</td>
</tr>
</tbody>
</table>
<hr>
<table style="width:75%" >
<tbody>
<tr>
<--! Second table-->

<td style="width: 70%">
Nom client : '.$factures[0][0].'<br>
Adresse : '.$factures[0][2].'<br>
Téléphone :'.$factures[0][1].' 
</td>
<td style="width:75%">
Préparé par : '.$_SESSION['info_user']['nom_user'].'<br>
Date de livraison : '.$factures[0][3].'
</td>
</tr>
</tbody>
</table>
<hr>
<h2 style="text-align:center">Facture</h2>

<table style="border-collapse: collapse; width:600px" border="1" >
<thead style="">
    <tr class="bg-success border rounded-0 border-info float-none" style="color: rgb(255,255,255);border-color=black;">
    <th style="color:black ;text-align:center;width:5%">N°</th>    
    <th style="color:black ;width:15%">Produit</th>
    <th style="color:black ;text-align:center ;width:15%" >Unité</th>
    <th style="color:black ;text-align:center ;width:15%">Quantite</th>
    <th style="color:black ;text-align:center ;width:15%">Prix unitaire</th>
    <th style="color:black ;text-align:center ;width:20%" >Totale</th>
    
    </tr>
</thead>
<tbody>';


$count = 1;
$totale_vente = 0;
while ($i<count($factures)) {
    $libelle_prod  =$factures[$i][4];
    $libelle_unit  =$factures[$i][5];
    $quantite  =$factures[$i][6];
    $prix_unitaire  =$factures[$i][7];
    $totale  =$factures[$i][8];
    $totale_vente += $totale;
    $content .= '<tr style="text-align:center"><td style="width:5% ">'.($count++).'</td>  <td style="width:15%">'.$libelle_prod.'</td>  <td style="width:15%">'.$libelle_unit.'</td><td style="width:15%">'.$quantite.'</td><td style="width:15%">'.$prix_unitaire.' Ar</td><td style="width:20%">'.$totale.' Ar</td></tr>';

    $i++;
}

$content .= '<tr style="text-align:center">
<td colspan="4"></td>
<td >Total</td>
<td >'.$totale_vente.' Ar</td>
</tr></tbody> </table>
<br><br>
<span>Si vous avez une question concernant la présente facture, n\'hésitez pas à nous contactez</span>
<p style="text-align:center; font-weight:bold">Nous vous remerçions de nous avoir choisie</p>';

$obj_pdf->writeHTML($content);

$obj_pdf->Output('Facture.pdf', 'I');
