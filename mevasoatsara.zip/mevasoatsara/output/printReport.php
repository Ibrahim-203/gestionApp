<?php

header('Content-Type: text/html; charset=utf-8');

$connection  = new mysqli("localhost", "root", "", "mevasoatsara");
require_once '../vendor/tcpdf_min/tcpdf.php';

class MYPDF extends TCPDF
{
    //Page header
    public function Header()
    {
        if($this->page==1) {
            // Logo
            $image_file = '../img/Logo.jpg';
            $this->Image($image_file, 10, 10, 15, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
            // Set font
            $this->SetFont('helvetica', 'B', 20);
            // Title
            $this->Cell(0, 15, 'Rapport Vente - Achat', 0, false, 'C', 0, '', 0, false, 'M', 'M');

        }
    }

    // Page footer
    public function Footer()
    {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('times', 'G', 7);
        // Page number
        // $this->Cell(0, 20, 'Avis important: Il ne peut être délivré qu’un seul exemplaire du présent relevé de notes. Aucun duplicata ne sera fourni.', 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }

    /**
     * @param bool $destroyall
     * @param bool $preserve_objcopy
     */
    public function _destroy($destroyall = false, $preserve_objcopy = false)
    {
        if ($destroyall) {
            unset($this->imagekeys);
        }
        parent::_destroy($destroyall, $preserve_objcopy);
    }
}


$obj_pdf = new MYPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$obj_pdf->SetCreator(PDF_CREATOR);
$obj_pdf->SetAuthor('Mevasoatsara');
$obj_pdf->SetKeywords('TESTE');
$obj_pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
$obj_pdf->setHeaderFont(array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$obj_pdf->setFooterFont(array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$obj_pdf->SetDefaultMonospacedFont('helvetica');
$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
$obj_pdf->SetMargins(PDF_MARGIN_LEFT, '5', PDF_MARGIN_RIGHT);
$obj_pdf->setPrintHeader(true);
$obj_pdf->setPrintFooter(true);
$obj_pdf->SetAutoPageBreak(true, 15);
$obj_pdf->SetFont('Times', '', 10);
$obj_pdf->AddPage();
//-----------------------------------Pdf custom --------------------------------

// Les 12 mois de l'année
$mois = ['janvier','fevrier','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
$annee = false;
// Check if the report request is by month or by year
if(isset($_GET['annee'])) {
    $id= $_GET['annee'];
    $queryVente = "SELECT `libelle_prod`,`libelle_unit`, `quantite`,D.`prix_unitaire`,D.`created_at`, `totale` FROM `vente_detail` D LEFT JOIN `produit` P ON D.produit_vendu = P.id_prod LEFT JOIN `unite` U ON U.id = D.unite_vente LEFT JOIN `vente_groupe` G ON D.id_vente_groupe = G.id_vente_groupe WHERE D.created_at LIKE '$id%' ORDER BY D.created_at;";
    $queryAchat = "SELECT `libelle_achat`,`unite_achat`,`quantite_achat`,`prix_unit`,`date_achat`, `total_achat` FROM `achat_detail` WHERE `date_achat` LIKE '$id%'";
    $annee = true;
} else {
    $id= $_GET['mois'];
    if($id<10) {
        $id_edited = '0'.$id;
    }
    $queryVente = "SELECT `libelle_prod`,`libelle_unit`, `quantite`,D.`prix_unitaire`,D.`created_at`, `totale` FROM `vente_detail` D LEFT JOIN `produit` P ON D.produit_vendu = P.id_prod LEFT JOIN `unite` U ON U.id = D.unite_vente LEFT JOIN `vente_groupe` G ON D.id_vente_groupe = G.id_vente_groupe WHERE D.created_at LIKE '%-$id_edited-%' ORDER BY D.created_at;";
    $queryAchat = "SELECT `libelle_achat`,`unite_achat`,`quantite_achat`,`prix_unit`,`date_achat`, `total_achat` FROM `achat_detail` WHERE `date_achat` LIKE '%-$id_edited-%'";
}

// get result from database inside variable
$rst1 = $connection->query($queryVente);
$rst2 = $connection->query($queryAchat);

$count = 1;
//$j est le compteur du mois et $i compteur qui parcours les deux tableaux
$j=1;
$i=0;

//Inserer les résultat du requêtte dans les tables $ventes et $achat
$vente = $rst1->fetch_all();
$achat = $rst2->fetch_all();
//Pour stockée la totale de vente mensuel
$chiffre_affaire = 0;
$depense = 0;
if($annee) {
    $obj_pdf->SetTitle("Rapport ".$id);
    $content = '<div style="text-align:center; "><h1> Rapport de l\'année '.$id.'</h1></div>';
    while($j<13) {

        $totale_vente_mensuel=0;
        $totale_achat_mensuel=0;
        $content.='<br><br><br><table style="border-collapse: collapse;margin-top:20px; padding:0.75rem" border="1" >
    <thead >
    <tr  style="text-align:center"><th colspan="8">Rapport du mois de '.$mois[$j-1].'</th></tr>
    <tr  style="border-color:black;background-color:#cdd8f6;text-align:center ">
    <th style="color:black ;width:5%">N°</th>
    <th style="color:black ;width:15%">Produit</th>
    <th style="color:black ;" >Unité</th>
    <th style="color:black ;width:10%">Quantite</th>
    <th style="color:black ;">Prix unitaire</th>
    <th style="color:black ;width:20%">Date de l\'opération</th>
    <th style="color:black ;" >Débit</th>
    <th style="color:black ;" >Crédit</th>

    </tr>
    
    </thead>
    <tbody>';
        $withvente = 0;
        $withachat = 0;
        while ($i<count($vente)) {
            $date = $vente[$i][4];
            $mounth = date('m', strtotime($date));
            $libelle_prod  =$vente[$i][0];
            $libelle_unit  =$vente[$i][1];
            $quantite  =$vente[$i][2];
            $prix_unitaire  =$vente[$i][3];
            $created_at = $vente[$i][4];
            $totale_vente  =$vente[$i][5];
            if($mounth==$j) {
                $withvente = 1;
                $totale_vente_mensuel+= $totale_vente;
                $content .= '<tr style="text-align:center"><td style="width:5% ">'.($count++).'</td>  <td style="width:15%">'.$libelle_prod.'</td>  <td>'.$libelle_unit.'</td><td style="width:10%">'.$quantite.'</td><td>'.number_format($prix_unitaire).' Ar</td><td style="width:20%">'.$created_at.'</td><td>'.number_format($totale_vente).' Ar </td><td> </td></tr>';

            }
            $chiffre_affaire += $totale_vente_mensuel;
            $i++;
        }
        $i=0;
        if($withvente==0) {
            $content .= '<tr ><td colspan="8"> Aucune vente effectué pour ce mois</td></tr>';
        }
        $content .= '<tr style="text-align:center"><td colspan="8">Achat </td></tr>';

        //
        while ($i<count($achat)) {
            $date = $achat[$i][4];
            $mounth_achat = date('m', strtotime($date));
            $libelle_achat  =$achat[$i][0];
            $unit_achat  =$achat[$i][1];
            $quantite_achat  =$achat[$i][2];
            $prix_unitaire_achat  =$achat[$i][3];
            $created_at_achat = $achat[$i][4];
            $totale_achat  =$achat[$i][5];
            if($mounth_achat==$j) {
                $withachat = 1;
                $totale_achat_mensuel+=$totale_achat;
                $content .= '<tr style="text-align:center"><td style="width:5%">'.($count++).'</td>  <td style="width:15%">'.$libelle_achat.'</td>  <td >'.$unit_achat.'</td><td style="width:10%">'.$quantite_achat.'</td><td >'.number_format($prix_unitaire_achat).' Ar</td><td style="width:20%">'.$created_at_achat.'</td><td > </td><td >'.number_format($totale_achat).'  Ar </td></tr>';
            }
            $depense += $totale_achat_mensuel;
            $i++;
        }
        $i=0;
        $j++;
        if($withachat==0) {
            $content .= '<tr ><td colspan="8">Aucune achat effectué pour ce mois</td></tr>';
        }
        $content .= '<tr style="text-align:center"><td colspan="6">Totale </td><td> '.number_format($totale_vente_mensuel).' Ar</td><td>'.number_format($totale_achat_mensuel). ' Ar</td></tr></tbody> </table>';

    }
} else {
    $obj_pdf->SetTitle("Rapport ".$mois[$id-1]);
    $totale_vente_mensuel=0;
    $totale_achat_mensuel=0;
    $content = '<div style="text-align:center; "><h1> Rapport du mois '.$mois[$id-1].'</h1></div>';
    $content.='<br><br><br><table style="border-collapse: collapse;margin-top:20px; padding:0.75rem" border="1" >
    <thead >
    <tr  style="text-align:center"><th colspan="8">Rapport du mois de '.$mois[$id-1].'</th></tr>
    <tr  style="border-color:black;background-color:#cdd8f6;text-align:center ">
    <th style="color:black ;width:5%">N°</th>
    <th style="color:black ;width:15%">Produit</th>
    <th style="color:black ;" >Unité</th>
    <th style="color:black ;width:10%">Quantite</th>
    <th style="color:black ;">Prix unitaire</th>
    <th style="color:black ;width:20%">Date de l\'opération</th>
    <th style="color:black ;" >Débit</th>
    <th style="color:black ;" >Crédit</th>

    </tr>
    
    </thead>
    <tbody>';

    while ($i<count($vente)) {

        $date = $vente[$i][4];
        $mounth = date('m', strtotime($date));
        $libelle_prod  =$vente[$i][0];
        $libelle_unit  =$vente[$i][1];
        $quantite  =$vente[$i][2];
        $prix_unitaire  =$vente[$i][3];
        $created_at = $vente[$i][4];
        $totale_vente  =$vente[$i][5];
        $totale_vente_mensuel+= $totale_vente;
        $content .= '<tr style="text-align:center"><td style="width:5% ">'.($count++).'</td>  <td style="width:15%">'.$libelle_prod.'</td>  <td>'.$libelle_unit.'</td><td style="width:10%">'.$quantite.'</td><td>'.number_format($prix_unitaire).' Ar</td><td style="width:20%">'.$created_at.'</td><td>'.number_format($totale_vente).' Ar </td><td> </td></tr>';


        $i++;
    }
    $i=0;
    $content .= '<tr style="text-align:center"><td colspan="8">Achat </td></tr>';

    //
    while ($i<count($achat)) {
        $date = $achat[$i][4];
        $mounth_achat = date('m', strtotime($date));
        $libelle_achat  =$achat[$i][0];
        $unit_achat  =$achat[$i][1];
        $quantite_achat  =$achat[$i][2];
        $prix_unitaire_achat  =$achat[$i][3];
        $created_at_achat = $achat[$i][4];
        $totale_achat  =$achat[$i][5];
        $totale_achat_mensuel+=$totale_achat;
        $content .= '<tr style="text-align:center"><td style="width:5%">'.($count++).'</td>  <td style="width:15%">'.$libelle_achat.'</td>  <td >'.$unit_achat.'</td><td style="width:10%">'.$quantite_achat.'</td><td >'.number_format($prix_unitaire_achat).' Ar</td><td style="width:20%">'.$created_at_achat.'</td><td > </td><td >'.number_format($totale_achat).'  Ar </td></tr>';


        $i++;
    }
    $i=0;
    $content .= '<tr style="text-align:center"><td colspan="6">Totale </td><td> '.number_format($totale_vente_mensuel).' Ar</td><td>'.number_format($totale_achat_mensuel). ' Ar</td></tr>';
    $content .= '</tbody> </table>';
}
$content .= '<br><br><div style ="text-align:right;background-color:#cdd8f6;width:10px"><p>Chiffre d\'affaire : '.number_format($chiffre_affaire).' Ar</p><p>Dépense : '.number_format($depense).' Ar</p></div>';


$obj_pdf->writeHTML($content);

$obj_pdf->Output('Rapport '.$id.'.pdf', 'I');
