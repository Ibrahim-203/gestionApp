<?php include './include/header.php'?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary title_near_btn">Liste des unités</h6>
        <button class="add_product btn btn-primary side_btn" id="add_unit">Ajouter une
            unité</button>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table_unit" id="table_unit" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th width="10%">Numero</th>
                        <th>Libelle</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Numero</th>
                        <th>Libelle</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>

                </tbody>
            </table>

        </div>
    </div>
</div>
<?php include './include/footer.php'?>
<script src="./model/js/unite.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>