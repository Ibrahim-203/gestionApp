<?php include './include/header.php'?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Utilisateur</h1>
    <p class="mb-4">Listes des utilisateurs </p>
    <!-- Table for the users -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary title_near_btn">Liste des utilisateurs</h6>
            <button class="add_user btn btn-primary side_btn" id="add_user">Ajouter un/une
                utilisateur</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table_user" id="table_user" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Nom et prénom</th>
                            <th>Téléphone</th>
                            <th>Adresse</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>id</th>
                            <th>Nom et prénom</th>
                            <th>Téléphone</th>
                            <th>Adresse</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php include './include/footer.php'?>
<script type="module" src="./model/js/user.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>