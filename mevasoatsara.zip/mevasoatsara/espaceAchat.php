<?php include './include/header.php'?>

<div class="container-fluid">

    <!-- Page Heading -->
    <!-- Table for the users -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary title_near_btn">Effectué une(des) achat(s)</h6>
        </div>
        <div class="row p-1">
            <div class="col-md-4 ">
                <label for="libelle_prod">libelle achat</label>
                <input type="text" name="libelle_achat" class="form form-control libelle_achat" id="libelle_achat">
            </div>
            <div class="col-md-4 ">
                <label for="quantite">quantite</label>
                <input type="text" name="quantite" class="form form-control quantite" id="quantite">
            </div>
            <div class="col-md-4 ">
                <label for="quantite">Unite d'achat</label>
                <input type="text" name="unite" class="form form-control unite" id="unite">
            </div>
        </div>
        <div class="row p-1">
            <div class="col-md-4 ">
                <label for="prix_unit">prix_unitaire </label>
                <input type="text" placeholder="en Ar" name="prix_unit" class="form form-control prix_unit"
                    id="prix_unit">
            </div>

            <div class="col-md-6 ">
                <label for="motif">Motif</label>
                <textarea rows="2" id="motif" name="motif" class="form-control motif" cols="5"></textarea>
            </div>



            <div class="col-md-2" style="margin-top: 2rem !important">
                <button type="button" class="btn btn-primary valid_achat" name="valid_achat"
                    id="valid_achat">Valider</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table_achat" id="table_achat" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th width="2%">id</th>
                            <th>Libelle achat</th>
                            <th width="20%">Motif</th>
                            <th>Quantite</th>
                            <th>Prix unitaire</th>
                            <th width="15%">Totale</th>
                            <th width="15%">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>id</th>
                            <th>Libelle achat</th>
                            <th>Motif</th>
                            <th>Quantite</th>
                            <th>Prix unitaire</th>
                            <th>Totale</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody id="achat_body">

                    </tbody>
                </table>


            </div>
            <div class="row">
                <div class="col-md-6">
                    <h6>Date de l'opération (optionnel)</h6>
                    <input type="date" id="date_achat" class="form-control date_achat">
                </div>
                <div class="col-md-6">
                    <h6>heure de l'opération (optionnel)</h6>
                    <input type="time" id="heure_achat" class="form-control heure_achat">
                </div>

            </div>
            <div class="container mt-2">
                <button type="button" id="btn_valid_achat" class="btn btn-success float-right btn_valid_achat "
                    disabled>Enregistrer</button>
            </div>
        </div>
    </div>

</div>

<?php include './include/footer.php'?>
<script type="module" src="./model/js/espaceAchat.js?v=<?php echo date('l jS of F Y h:i:s A'); ?>"></script>